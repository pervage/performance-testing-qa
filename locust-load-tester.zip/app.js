// Application Data
const appData = {
  testPlans: [
    {
      id: "1",
      name: "E-commerce API Load Test",
      description: "Test critical e-commerce endpoints",
      apis: [
        {
          name: "Login API",
          method: "POST",
          url: "/api/auth/login",
          body: '{"username": "testuser", "password": "testpass"}'
        },
        {
          name: "Product Catalog",
          method: "GET",
          url: "/api/products",
          headers: {"Authorization": "Bearer {{login_token}}"}
        }
      ],
      users: 100,
      spawnRate: 10,
      runtime: "5m"
    },
    {
      id: "2",
      name: "AWS API Gateway Test",
      description: "Load test AWS API Gateway endpoints",
      aws: {
        region: "us-east-1",
        service: "API Gateway",
        endpoints: ["https://api.example.com/v1/users"]
      }
    }
  ],
  csvFiles: [
    {
      name: "user_data.csv",
      columns: ["username", "email", "user_id"],
      rows: 1000
    },
    {
      name: "product_data.csv", 
      columns: ["product_id", "name", "price"],
      rows: 500
    }
  ],
  awsServices: [
    {
      name: "EC2 Instance",
      type: "ec2",
      endpoint: "https://ec2.us-east-1.amazonaws.com"
    },
    {
      name: "RDS Database",
      type: "rds",
      endpoint: "mydb.cluster-123.us-east-1.rds.amazonaws.com"
    }
  ],
  monitoringData: {
    currentUsers: 50,
    requestsPerSecond: 120,
    averageResponseTime: 150,
    errorRate: 2.5,
    timeSeriesData: [
      {time: "10:00", requests: 100, errors: 2},
      {time: "10:01", requests: 110, errors: 1},
      {time: "10:02", requests: 120, errors: 3},
      {time: "10:03", requests: 115, errors: 2},
      {time: "10:04", requests: 130, errors: 4}
    ]
  }
};

// Global variables
let currentSection = 'dashboard';
let apiChain = [];
let webScenarios = [];
let activeTests = [];
let charts = {};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
  console.log('Application initializing...');
  initializeNavigation();
  initializeCharts();
  initializeForms();
  initializeFileUploads();
  initializeRealTimeUpdates();
  loadInitialData();
  
  // Initialize test plans display
  initializeTestPlansDisplay();
});

// Navigation functionality
function initializeNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('.content-section');
  
  console.log('Found nav links:', navLinks.length);
  console.log('Found sections:', sections.length);
  
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetSection = link.getAttribute('data-section');
      console.log('Navigating to:', targetSection);
      
      // Update active nav link
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      
      // Show target section
      sections.forEach(section => {
        section.classList.remove('active');
        if (section.id === targetSection) {
          section.classList.add('active');
          console.log('Activated section:', section.id);
        }
      });
      
      currentSection = targetSection;
      
      // Update section-specific content
      updateSectionContent(targetSection);
    });
  });
}

// Initialize charts
function initializeCharts() {
  // Dashboard Activity Chart
  const activityCtx = document.getElementById('activityChart');
  if (activityCtx) {
    charts.activity = new Chart(activityCtx, {
      type: 'line',
      data: {
        labels: appData.monitoringData.timeSeriesData.map(d => d.time),
        datasets: [{
          label: 'Requests',
          data: appData.monitoringData.timeSeriesData.map(d => d.requests),
          borderColor: '#1FB8CD',
          backgroundColor: 'rgba(31, 184, 205, 0.1)',
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }
  
  // Performance Chart
  const performanceCtx = document.getElementById('performanceChart');
  if (performanceCtx) {
    charts.performance = new Chart(performanceCtx, {
      type: 'line',
      data: {
        labels: appData.monitoringData.timeSeriesData.map(d => d.time),
        datasets: [{
          label: 'Requests/sec',
          data: appData.monitoringData.timeSeriesData.map(d => d.requests),
          borderColor: '#1FB8CD',
          backgroundColor: 'rgba(31, 184, 205, 0.1)',
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top'
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }
  
  // Error Rate Chart
  const errorCtx = document.getElementById('errorChart');
  if (errorCtx) {
    charts.errors = new Chart(errorCtx, {
      type: 'bar',
      data: {
        labels: appData.monitoringData.timeSeriesData.map(d => d.time),
        datasets: [{
          label: 'Errors',
          data: appData.monitoringData.timeSeriesData.map(d => d.errors),
          backgroundColor: '#FFC185',
          borderColor: '#B4413C',
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top'
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }
}

// Initialize forms
function initializeForms() {
  // API Form
  const apiForm = document.getElementById('api-form');
  if (apiForm) {
    apiForm.addEventListener('submit', handleApiFormSubmit);
  }
  
  // Web Form
  const webForm = document.getElementById('web-form');
  if (webForm) {
    webForm.addEventListener('submit', handleWebFormSubmit);
  }
  
  // AWS Form
  const awsForm = document.getElementById('aws-form');
  if (awsForm) {
    awsForm.addEventListener('submit', handleAwsFormSubmit);
  }
  
  // JMX Settings Form
  const jmxForm = document.getElementById('jmx-settings-form');
  if (jmxForm) {
    jmxForm.addEventListener('submit', handleJmxFormSubmit);
  }
  
  // Locust Config Form
  const locustForm = document.getElementById('locust-config-form');
  if (locustForm) {
    locustForm.addEventListener('submit', handleLocustConfigSubmit);
  }
  
  // New Test Plan Button
  const newPlanBtn = document.getElementById('new-plan-btn');
  if (newPlanBtn) {
    newPlanBtn.addEventListener('click', createNewTestPlan);
  }
}

// Initialize file uploads
function initializeFileUploads() {
  // CSV Upload
  const csvUpload = document.getElementById('csv-upload');
  const csvFileInput = document.getElementById('csv-file-input');
  
  if (csvUpload && csvFileInput) {
    csvUpload.addEventListener('click', () => csvFileInput.click());
    csvUpload.addEventListener('dragover', handleDragOver);
    csvUpload.addEventListener('drop', handleCsvDrop);
    csvFileInput.addEventListener('change', handleCsvFileSelect);
  }
  
  // JMX Upload
  const jmxUpload = document.getElementById('jmx-upload-area');
  const jmxFileInput = document.getElementById('jmx-file-input');
  
  if (jmxUpload && jmxFileInput) {
    jmxUpload.addEventListener('click', () => jmxFileInput.click());
    jmxUpload.addEventListener('dragover', handleDragOver);
    jmxUpload.addEventListener('drop', handleJmxDrop);
    jmxFileInput.addEventListener('change', handleJmxFileSelect);
  }
}

// Form handlers
function handleApiFormSubmit(e) {
  e.preventDefault();
  
  const apiData = {
    name: document.getElementById('api-name').value,
    method: document.getElementById('api-method').value,
    url: document.getElementById('api-url').value,
    headers: document.getElementById('api-headers').value,
    body: document.getElementById('api-body').value,
    responseVar: document.getElementById('response-var').value
  };
  
  // Add to API chain
  apiChain.push(apiData);
  updateApiChain();
  
  // Clear form
  e.target.reset();
  
  showNotification('API endpoint added successfully', 'success');
}

function handleWebFormSubmit(e) {
  e.preventDefault();
  
  const webData = {
    url: document.getElementById('web-url').value,
    userAgent: document.getElementById('user-agent').value,
    loadImages: document.getElementById('load-images').value === 'true',
    additionalPages: document.getElementById('additional-pages').value.split(',').map(p => p.trim()).filter(p => p)
  };
  
  webScenarios.push(webData);
  updateWebScenarios();
  
  e.target.reset();
  showNotification('Web test scenario added successfully', 'success');
}

function handleAwsFormSubmit(e) {
  e.preventDefault();
  
  const awsData = {
    region: document.getElementById('aws-region').value,
    service: document.getElementById('aws-service').value,
    endpoint: document.getElementById('aws-endpoint').value,
    accessKey: document.getElementById('aws-access-key').value,
    secretKey: document.getElementById('aws-secret-key').value
  };
  
  // Add to AWS services
  appData.awsServices.push({
    name: `${awsData.service} - ${awsData.region}`,
    type: awsData.service,
    endpoint: awsData.endpoint
  });
  
  updateAwsServices();
  e.target.reset();
  showNotification('AWS service configuration added successfully', 'success');
}

function handleJmxFormSubmit(e) {
  e.preventDefault();
  
  const outputFormat = document.getElementById('output-format').value;
  const variableExtraction = document.getElementById('variable-extraction').value;
  
  showNotification('JMX conversion started', 'info');
  
  // Simulate conversion process
  setTimeout(() => {
    showNotification('JMX file converted to Locust format successfully', 'success');
  }, 2000);
}

function handleLocustConfigSubmit(e) {
  e.preventDefault();
  
  const config = {
    numUsers: document.getElementById('num-users').value,
    spawnRate: document.getElementById('spawn-rate').value,
    runtime: document.getElementById('runtime').value
  };
  
  showNotification('Locust configuration saved successfully', 'success');
}

// File upload handlers
function handleDragOver(e) {
  e.preventDefault();
  e.currentTarget.style.borderColor = 'var(--color-primary)';
  e.currentTarget.style.backgroundColor = 'var(--color-secondary)';
}

function handleCsvDrop(e) {
  e.preventDefault();
  const files = e.dataTransfer.files;
  processCsvFiles(files);
  resetUploadArea(e.currentTarget);
}

function handleJmxDrop(e) {
  e.preventDefault();
  const files = e.dataTransfer.files;
  processJmxFiles(files);
  resetUploadArea(e.currentTarget);
}

function handleCsvFileSelect(e) {
  processCsvFiles(e.target.files);
}

function handleJmxFileSelect(e) {
  processJmxFiles(e.target.files);
}

function resetUploadArea(element) {
  element.style.borderColor = '';
  element.style.backgroundColor = '';
}

function processCsvFiles(files) {
  Array.from(files).forEach(file => {
    if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
      const reader = new FileReader();
      reader.onload = function(e) {
        const csvData = e.target.result;
        const lines = csvData.split('\n');
        const headers = lines[0].split(',');
        
        appData.csvFiles.push({
          name: file.name,
          columns: headers,
          rows: lines.length - 1
        });
        
        updateCsvFilesList();
        showNotification(`CSV file "${file.name}" uploaded successfully`, 'success');
      };
      reader.readAsText(file);
    }
  });
}

function processJmxFiles(files) {
  Array.from(files).forEach(file => {
    if (file.name.endsWith('.jmx')) {
      const reader = new FileReader();
      reader.onload = function(e) {
        const jmxContent = e.target.result;
        // Simulate JMX parsing
        showNotification(`JMX file "${file.name}" uploaded successfully`, 'success');
        
        // Add to conversion queue
        setTimeout(() => {
          showNotification(`JMX file "${file.name}" ready for conversion`, 'info');
        }, 1000);
      };
      reader.readAsText(file);
    }
  });
}

// Update functions
function updateApiChain() {
  const chainContainer = document.getElementById('api-chain');
  if (!chainContainer) return;
  
  chainContainer.innerHTML = '';
  
  if (apiChain.length === 0) {
    chainContainer.innerHTML = '<p>No API endpoints added yet. Add your first API endpoint to start building a chain.</p>';
    return;
  }
  
  apiChain.forEach((api, index) => {
    const chainItem = document.createElement('div');
    chainItem.className = 'chain-item';
    chainItem.innerHTML = `
      <div class="chain-header">
        <h4>${api.name}</h4>
        <span class="chain-method">${api.method}</span>
      </div>
      <div class="chain-url">${api.url}</div>
      <div class="chain-variable">${api.responseVar ? `→ ${api.responseVar}` : ''}</div>
    `;
    
    chainContainer.appendChild(chainItem);
    
    if (index < apiChain.length - 1) {
      const arrow = document.createElement('div');
      arrow.className = 'chain-arrow';
      arrow.textContent = '↓';
      chainContainer.appendChild(arrow);
    }
  });
}

function updateWebScenarios() {
  const scenariosContainer = document.querySelector('.web-scenarios');
  if (!scenariosContainer) return;
  
  scenariosContainer.innerHTML = '';
  
  if (webScenarios.length === 0) {
    scenariosContainer.innerHTML = '<p>No web test scenarios added yet. Add your first web test scenario above.</p>';
    return;
  }
  
  webScenarios.forEach((scenario, index) => {
    const scenarioItem = document.createElement('div');
    scenarioItem.className = 'scenario-item';
    scenarioItem.innerHTML = `
      <div class="scenario-info">
        <h4>Web Test ${index + 1}</h4>
        <p>${scenario.url}</p>
      </div>
      <div class="scenario-actions">
        <span class="status status--info">Ready</span>
        <button class="btn btn--sm btn--outline" onclick="runWebTest(${index})">Run</button>
      </div>
    `;
    
    scenariosContainer.appendChild(scenarioItem);
  });
}

function updateAwsServices() {
  const servicesContainer = document.querySelector('.aws-services-list');
  if (!servicesContainer) return;
  
  servicesContainer.innerHTML = '';
  
  if (appData.awsServices.length === 0) {
    servicesContainer.innerHTML = '<p>No AWS services configured yet. Add your first AWS service above.</p>';
    return;
  }
  
  appData.awsServices.forEach((service, index) => {
    const serviceItem = document.createElement('div');
    serviceItem.className = 'service-item';
    serviceItem.innerHTML = `
      <div class="service-info">
        <h4>${service.name}</h4>
        <p>${service.endpoint}</p>
      </div>
      <div class="service-actions">
        <span class="status status--success">Connected</span>
        <button class="btn btn--sm btn--outline" onclick="testAwsService(${index})">Test</button>
      </div>
    `;
    
    servicesContainer.appendChild(serviceItem);
  });
}

function updateCsvFilesList() {
  const filesContainer = document.querySelector('.csv-files-list');
  if (!filesContainer) return;
  
  filesContainer.innerHTML = '';
  
  if (appData.csvFiles.length === 0) {
    filesContainer.innerHTML = '<p>No CSV files uploaded yet. Upload your first CSV file above.</p>';
    return;
  }
  
  appData.csvFiles.forEach((file, index) => {
    const fileItem = document.createElement('div');
    fileItem.className = 'csv-file-item';
    fileItem.innerHTML = `
      <div class="file-info">
        <h4>${file.name}</h4>
        <p>${file.rows} rows • ${file.columns.join(', ')}</p>
      </div>
      <div class="file-actions">
        <button class="btn btn--sm btn--outline" onclick="previewCsvFile(${index})">Preview</button>
        <button class="btn btn--sm btn--outline" onclick="downloadCsvFile(${index})">Download</button>
      </div>
    `;
    
    filesContainer.appendChild(fileItem);
  });
}

function initializeTestPlansDisplay() {
  const testPlansGrid = document.querySelector('.test-plans-grid');
  if (!testPlansGrid) return;
  
  testPlansGrid.innerHTML = '';
  
  appData.testPlans.forEach((plan, index) => {
    const planCard = document.createElement('div');
    planCard.className = 'card test-plan-card';
    planCard.innerHTML = `
      <div class="card__body">
        <h3>${plan.name}</h3>
        <p>${plan.description}</p>
        <div class="plan-details">
          <div class="detail-item">
            <strong>Users:</strong> ${plan.users || 'N/A'}
          </div>
          <div class="detail-item">
            <strong>Spawn Rate:</strong> ${plan.spawnRate || 'N/A'}/sec
          </div>
          <div class="detail-item">
            <strong>Runtime:</strong> ${plan.runtime || 'N/A'}
          </div>
        </div>
        <div class="plan-actions">
          <button class="btn btn--primary btn--sm" onclick="runTestPlan(${index})">Run Test</button>
          <button class="btn btn--outline btn--sm" onclick="editTestPlan(${index})">Edit</button>
          <button class="btn btn--outline btn--sm" onclick="exportTestPlan(${index})">Export</button>
        </div>
      </div>
    `;
    
    testPlansGrid.appendChild(planCard);
  });
}

function updateSectionContent(section) {
  switch(section) {
    case 'dashboard':
      updateDashboardMetrics();
      break;
    case 'monitoring':
      updateMonitoringCharts();
      break;
    case 'test-plans':
      updateTestPlans();
      break;
    case 'api-testing':
      updateApiChain();
      break;
    case 'web-testing':
      updateWebScenarios();
      break;
    case 'aws-testing':
      updateAwsServices();
      break;
  }
}

function updateDashboardMetrics() {
  // Update metric values
  const metrics = [
    { selector: '.dashboard-grid .metric-card:nth-child(1) .metric-value', value: activeTests.length },
    { selector: '.dashboard-grid .metric-card:nth-child(2) .metric-value', value: appData.monitoringData.currentUsers },
    { selector: '.dashboard-grid .metric-card:nth-child(3) .metric-value', value: appData.monitoringData.requestsPerSecond },
    { selector: '.dashboard-grid .metric-card:nth-child(4) .metric-value', value: appData.monitoringData.errorRate + '%' }
  ];
  
  metrics.forEach(metric => {
    const element = document.querySelector(metric.selector);
    if (element) {
      element.textContent = metric.value;
    }
  });
}

function updateMonitoringCharts() {
  // Update charts with new data
  if (charts.performance) {
    charts.performance.data.labels = appData.monitoringData.timeSeriesData.map(d => d.time);
    charts.performance.data.datasets[0].data = appData.monitoringData.timeSeriesData.map(d => d.requests);
    charts.performance.update();
  }
  
  if (charts.errors) {
    charts.errors.data.labels = appData.monitoringData.timeSeriesData.map(d => d.time);
    charts.errors.data.datasets[0].data = appData.monitoringData.timeSeriesData.map(d => d.errors);
    charts.errors.update();
  }
}

function updateTestPlans() {
  initializeTestPlansDisplay();
}

// Action handlers
function runWebTest(index) {
  const scenario = webScenarios[index];
  showNotification(`Starting web test for ${scenario.url}`, 'info');
  
  // Simulate test execution
  setTimeout(() => {
    showNotification(`Web test completed for ${scenario.url}`, 'success');
  }, 3000);
}

function testAwsService(index) {
  const service = appData.awsServices[index];
  showNotification(`Testing connection to ${service.name}`, 'info');
  
  // Simulate connection test
  setTimeout(() => {
    showNotification(`Connection test successful for ${service.name}`, 'success');
  }, 2000);
}

function previewCsvFile(index) {
  const file = appData.csvFiles[index];
  showNotification(`Previewing ${file.name}`, 'info');
}

function downloadCsvFile(index) {
  const file = appData.csvFiles[index];
  showNotification(`Downloading ${file.name}`, 'info');
  
  // Simulate file download
  setTimeout(() => {
    showNotification(`${file.name} downloaded successfully`, 'success');
  }, 1000);
}

function runTestPlan(index) {
  const plan = appData.testPlans[index];
  showNotification(`Starting test plan: ${plan.name}`, 'info');
  
  setTimeout(() => {
    showNotification(`Test plan "${plan.name}" completed successfully`, 'success');
  }, 3000);
}

function editTestPlan(index) {
  const plan = appData.testPlans[index];
  showNotification(`Editing test plan: ${plan.name}`, 'info');
}

function exportTestPlan(index) {
  const plan = appData.testPlans[index];
  showNotification(`Exporting test plan: ${plan.name}`, 'info');
  
  setTimeout(() => {
    showNotification(`Test plan "${plan.name}" exported successfully`, 'success');
  }, 1000);
}

function createNewTestPlan() {
  showNotification('Creating new test plan', 'info');
  
  const newPlan = {
    id: Date.now().toString(),
    name: 'New Test Plan',
    description: 'Enter description',
    users: 10,
    spawnRate: 1,
    runtime: '1m'
  };
  
  appData.testPlans.push(newPlan);
  initializeTestPlansDisplay();
  showNotification('New test plan created', 'success');
}

// Real-time updates
function initializeRealTimeUpdates() {
  // Simulate real-time data updates
  setInterval(() => {
    if (currentSection === 'dashboard' || currentSection === 'monitoring') {
      // Update monitoring data
      const newDataPoint = {
        time: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }),
        requests: Math.floor(Math.random() * 50) + 100,
        errors: Math.floor(Math.random() * 5)
      };
      
      appData.monitoringData.timeSeriesData.push(newDataPoint);
      
      // Keep only last 10 data points
      if (appData.monitoringData.timeSeriesData.length > 10) {
        appData.monitoringData.timeSeriesData.shift();
      }
      
      // Update current metrics
      appData.monitoringData.requestsPerSecond = newDataPoint.requests;
      appData.monitoringData.errorRate = (newDataPoint.errors / newDataPoint.requests * 100).toFixed(1);
      
      // Update UI
      updateDashboardMetrics();
      updateMonitoringCharts();
      
      // Update activity chart
      if (charts.activity) {
        charts.activity.data.labels = appData.monitoringData.timeSeriesData.map(d => d.time);
        charts.activity.data.datasets[0].data = appData.monitoringData.timeSeriesData.map(d => d.requests);
        charts.activity.update();
      }
    }
  }, 5000); // Update every 5 seconds
}

// Load initial data
function loadInitialData() {
  // Update API chain with initial data
  apiChain = [
    {
      name: "Login API",
      method: "POST",
      url: "/api/auth/login",
      body: '{"username": "testuser", "password": "testpass"}',
      responseVar: "login_token"
    },
    {
      name: "Product Catalog",
      method: "GET",
      url: "/api/products",
      headers: '{"Authorization": "Bearer {{login_token}}"}',
      responseVar: ""
    }
  ];
  
  updateApiChain();
  updateCsvFilesList();
  updateAwsServices();
  updateWebScenarios();
  updateDashboardMetrics();
  initializeTestPlansDisplay();
}

// Utility functions
function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification notification--${type}`;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    border-radius: 8px;
    color: white;
    font-weight: 500;
    z-index: 1000;
    animation: slideIn 0.3s ease-out;
  `;
  
  // Set background color based on type
  const colors = {
    success: '#1FB8CD',
    error: '#B4413C',
    warning: '#FFC185',
    info: '#5D878F'
  };
  
  notification.style.backgroundColor = colors[type] || colors.info;
  notification.textContent = message;
  
  // Add to DOM
  document.body.appendChild(notification);
  
  // Remove after 3 seconds
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease-out';
    setTimeout(() => {
      if (document.body.contains(notification)) {
        document.body.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

// Add CSS animations for notifications
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  
  @keyframes slideOut {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
  }
`;
document.head.appendChild(style);

// Export functions for button onclick handlers
window.runWebTest = runWebTest;
window.testAwsService = testAwsService;
window.previewCsvFile = previewCsvFile;
window.downloadCsvFile = downloadCsvFile;
window.runTestPlan = runTestPlan;
window.editTestPlan = editTestPlan;
window.exportTestPlan = exportTestPlan;