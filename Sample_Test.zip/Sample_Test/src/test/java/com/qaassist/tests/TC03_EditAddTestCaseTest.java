package com.qaassist.tests;

import com.qaassist.api.TestCaseAPI;
import com.qaassist.base.BaseTest;
import com.qaassist.config.ConfigReader;
import com.qaassist.constants.Constants;
import com.qaassist.listeners.RetryAnalyzer;
import com.qaassist.listeners.TestListener;
import com.qaassist.pages.DashboardPage;
import com.qaassist.pages.LoginPage;
import com.qaassist.pages.TestCaseManagerPage;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

/**
 * TC_03 — Edit and Add Test Case
 *
 * Description: Edit the test case and add the test case to a Test Suite.
 *
 * Pre-requisites:
 * - Valid SSO session
 * - Project HU_QE_EDGE selectable
 */
@Listeners(TestListener.class)
public class TC03_EditAddTestCaseTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private TestCaseManagerPage testCaseManagerPage;
    private TestCaseAPI testCaseAPI;

    private String projectId;
    private String suiteId;

    @BeforeMethod(alwaysRun = true)
    public void initPages() {
        loginPage = new LoginPage(getDriver());
        testCaseAPI = new TestCaseAPI();
        projectId = ConfigReader.getProjectId();
        suiteId = ConfigReader.getProperty("test.suite.id", "default-suite");
    }

    @Test(priority = 1, groups = {"regression"},
            description = "TC_03: Edit and Add Test Case to Test Suite",
            retryAnalyzer = RetryAnalyzer.class)
    public void testEditAndAddTestCase() {
        createExtentTest("TC_03_EditAddTestCase",
                "Edit test case, add via API, remove via API, verify in UI");

        // ── Step 1: Launch QA Assist and verify Dashboard ──
        logStep("Step 1: Launching QA Assist and verifying Dashboard");
        dashboardPage = loginPage.loginWithSSOProfile(ConfigReader.getBaseUrl());
        Assert.assertTrue(dashboardPage.isDashboardDisplayed(),
                "Dashboard should load successfully");
        logPassStep("Dashboard loaded successfully");

        // ── Step 2: Select Test Case Manager ──
        logStep("Step 2: Selecting Test Case Manager");
        testCaseManagerPage = dashboardPage.navigateToTestCaseManager();
        logPassStep("Test Case Manager opened");

        // ── Step 3: Select project HU_QE_EDGE ──
        logStep("Step 3: Selecting project " + Constants.PROJECT_HU_QE_EDGE);
        testCaseManagerPage.selectProject(Constants.PROJECT_HU_QE_EDGE);
        logPassStep("Project selected: " + Constants.PROJECT_HU_QE_EDGE);

        // ── Step 4: Select Open Test Manager ──
        logStep("Step 4: Opening Test Manager");
        testCaseManagerPage.clickOpenTestManager();
        logPassStep("Test Manager opened");

        // ── Step 5: Select first test case in NopCommerce folder, select Test Steps ──
        logStep("Step 5: Selecting first test case in NopCommerce folder");
        testCaseManagerPage.clickFolder("NopCommerce");
        testCaseManagerPage.openFirstTestCase();

        // Note down the test case ID
        String testCaseId = testCaseManagerPage.getTestCaseId();
        logStep("Test Case ID noted: " + testCaseId);

        testCaseManagerPage.clickTestStepsTab();
        logPassStep("Test case opened and Test Steps tab selected");

        // ── Step 6: Edit first test step ──
        logStep("Step 6: Clicking Edit Steps, editing first test step");
        testCaseManagerPage.clickEditSteps();
        testCaseManagerPage.editFirstTestStep("Updated test step by automation - TC_03");
        testCaseManagerPage.clickDoneEditing();
        testCaseManagerPage.clickSaveChanges();
        logPassStep("Test step edited and saved successfully");

        // ── Step 7: Select WebAutomation persona and go to HU_QE_EDGE project ──
        logStep("Step 7: Selecting WebAutomation persona and navigating to HU_QE_EDGE project");
        dashboardPage.selectPersona(Constants.PERSONA_WEB_AUTOMATION);
        dashboardPage.selectProject(Constants.PROJECT_HU_QE_EDGE);
        logPassStep("WebAutomation persona selected, all Test Suites shown");

        // ── Step 8: API — Add test case ──
        logStep("Step 8: API — Adding test case to suite");
        Response addResponse = testCaseAPI.addTestCase(
                projectId,
                suiteId,
                "Automated Test Case - TC_03",
                "Test case added via API automation",
                "High");
        Assert.assertTrue(
                addResponse.getStatusCode() == 200 || addResponse.getStatusCode() == 201,
                "Add test case API should return 200/201. Got: " + addResponse.getStatusCode());
        String newTestCaseId = testCaseAPI.getTestCaseIdFromResponse(addResponse);
        Assert.assertNotNull(newTestCaseId, "New test case ID should not be null");
        logPassStep("Test case added via API — ID: " + newTestCaseId);

        // Verify in UI (refresh and check)
        logStep("Verifying newly added test case appears in UI");
        // The test case should appear after refresh
        captureSuccessScreenshot("TestCase_Added_Verification");

        // ── Step 9: API — Remove the newly added test case ──
        logStep("Step 9: API — Removing the newly added test case");
        Response removeResponse = testCaseAPI.removeTestCase(projectId, suiteId, newTestCaseId);
        Assert.assertEquals(removeResponse.getStatusCode(), 200,
                "Remove test case API should return 200. Got: " + removeResponse.getStatusCode());
        logPassStep("Test case removed via API — ID: " + newTestCaseId);

        // Verify removal in UI
        logStep("Verifying removed test case no longer appears in UI");
        captureSuccessScreenshot("TestCase_Removed_Verification");

        logStep("TC_03 COMPLETED — Test case edited, added via API, removed via API");
    }
}
