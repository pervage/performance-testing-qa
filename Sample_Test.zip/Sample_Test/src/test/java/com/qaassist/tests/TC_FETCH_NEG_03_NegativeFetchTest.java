package com.qaassist.tests;

import com.qaassist.base.BaseTest;
import com.qaassist.config.ConfigReader;
import com.qaassist.constants.Constants;
import com.qaassist.listeners.RetryAnalyzer;
import com.qaassist.listeners.TestListener;
import com.qaassist.pages.AIAssistantPage;
import com.qaassist.pages.DashboardPage;
import com.qaassist.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

/**
 * TC_FETCH_NEG_03 — Negative: Fetch Test Case from Chatbot
 *
 * Description: Search for non-available tests and verify error message is displayed.
 *
 * Pre-requisites:
 * - Valid SSO session
 * - Project HU_QE_EDGE selectable
 */
@Listeners(TestListener.class)
public class TC_FETCH_NEG_03_NegativeFetchTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private AIAssistantPage aiAssistantPage;

    @BeforeMethod(alwaysRun = true)
    public void initPages() {
        loginPage = new LoginPage(getDriver());
    }

    @Test(priority = 1, groups = {"regression", "negative"},
            description = "TC_FETCH_NEG_03: Negative - Fetch non-available test cases from chatbot",
            retryAnalyzer = RetryAnalyzer.class)
    public void testNegativeFetchFromChatbot() {
        createExtentTest("TC_FETCH_NEG_03_NegativeFetch",
                "Search for non-available tests and verify error message is shown");

        // ── Step 1: Launch QA Assist and select HU_QE_EDGE ──
        logStep("Step 1: Launching QA Assist and selecting project " + Constants.PROJECT_HU_QE_EDGE);
        dashboardPage = loginPage.loginWithSSOProfile(ConfigReader.getBaseUrl());
        Assert.assertTrue(dashboardPage.isDashboardDisplayed(),
                "Dashboard should be displayed");
        dashboardPage.selectProject(Constants.PROJECT_HU_QE_EDGE);
        logPassStep("Project selected: " + Constants.PROJECT_HU_QE_EDGE);

        // ── Step 2: Click on Agent Assist and provide prompt ──
        logStep("Step 2: Opening Agent Assist and sending negative prompt");
        aiAssistantPage = dashboardPage.navigateToAIAssistant();
        Assert.assertTrue(aiAssistantPage.isChatPanelOpen(),
                "Agent Assist panel should be open");

        aiAssistantPage.sendQuery(Constants.AI_FETCH_SAMSUNG);
        logStep("Sent AI prompt: " + Constants.AI_FETCH_SAMSUNG);

        // Wait for response
        aiAssistantPage.waitForAIResponse();
        logPassStep("AI response received for negative query");

        // ── Step 3: Assert the error message ──
        logStep("Step 3: Asserting error message is displayed");
        Assert.assertTrue(aiAssistantPage.isErrorMessageDisplayed(),
                "Error message should be displayed for non-available tests");

        String errorMessage = aiAssistantPage.getErrorMessage();
        Assert.assertNotNull(errorMessage, "Error message text should not be null");
        Assert.assertFalse(errorMessage.isEmpty(), "Error message should not be empty");

        logger.info("Error message captured: {}", errorMessage);
        logPassStep("Error message displayed: " + errorMessage);

        logStep("TC_FETCH_NEG_03 COMPLETED — Negative test case validated with error message");
    }
}
