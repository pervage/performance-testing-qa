package com.qaassist.tests;

import com.qaassist.base.BaseTest;
import com.qaassist.config.ConfigReader;
import com.qaassist.constants.Constants;
import com.qaassist.listeners.RetryAnalyzer;
import com.qaassist.listeners.TestListener;
import com.qaassist.pages.DashboardPage;
import com.qaassist.pages.LoginPage;
import com.qaassist.pages.TestCaseManagerPage;
import com.qaassist.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.util.Map;

/**
 * TC_05 — Delete Folder (Excel Folder) and Verify Removal
 *
 * Description: Deletes the folder created from Excel upload and verifies it disappears from UI.
 *
 * Pre-requisites:
 * - Folder exists (from Excel upload)
 * - User has delete permissions
 */
@Listeners(TestListener.class)
public class TC05_DeleteFolderTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private TestCaseManagerPage testCaseManagerPage;

    private String folderName;

    @BeforeMethod(alwaysRun = true)
    public void initPages() {
        loginPage = new LoginPage(getDriver());

        // Get folder name from Excel (Module/Folder column)
        String excelPath = new File(ConfigReader.getExcelUploadPath()).getAbsolutePath();
        Map<String, String> firstRow = ExcelUtils.readFirstRow(excelPath, "TestCases");
        folderName = firstRow.get(Constants.COL_MODULE_FOLDER);
    }

    @Test(priority = 1, groups = {"regression"},
            description = "TC_05: Delete folder created from Excel upload and verify removal",
            retryAnalyzer = RetryAnalyzer.class)
    public void testDeleteFolderAndVerifyRemoval() {
        createExtentTest("TC_05_DeleteFolderVerify",
                "Delete the Excel-uploaded folder and verify it disappears from UI");

        // ── Step 1: Identify folder name from Excel ──
        logStep("Step 1: Identified folder from Excel (Module/Folder): " + folderName);
        Assert.assertNotNull(folderName, "Folder name from Excel should not be null");
        logPassStep("Correct folder targeted: " + folderName);

        // ── Step 2: Launch QA Assist and navigate to Test Case Manager ──
        logStep("Step 2: Launching QA Assist and navigating to Test Case Manager");
        dashboardPage = loginPage.loginWithSSOProfile(ConfigReader.getBaseUrl());
        Assert.assertTrue(dashboardPage.isDashboardDisplayed(),
                "Dashboard should be displayed");
        testCaseManagerPage = dashboardPage.navigateToTestCaseManager();
        logPassStep("Test Case Manager opened");

        // ── Step 3: Verify folder exists before deletion ──
        logStep("Step 3: Verifying folder exists: " + folderName);
        Assert.assertTrue(testCaseManagerPage.isFolderVisible(folderName),
                "Folder should exist before deletion: " + folderName);
        logPassStep("Folder confirmed to exist");

        // ── Step 4: Click three-dots menu for that folder ──
        logStep("Step 4: Opening folder action menu (three-dots)");
        testCaseManagerPage.clickFolderMenu(folderName);
        logPassStep("Folder action menu opened");

        // ── Step 5: Choose Delete Folder ──
        logStep("Step 5: Choosing 'Delete Folder' from menu");
        testCaseManagerPage.clickDeleteFolder();
        logPassStep("Delete confirmation appeared");

        // ── Step 6: Confirm delete in popup ──
        logStep("Step 6: Confirming folder deletion in popup");
        testCaseManagerPage.confirmDelete();
        logPassStep("Folder deletion executed");

        // ── Step 7: Verify folder no longer appears ──
        logStep("Step 7: Verifying folder no longer appears in list/tree");
        Assert.assertTrue(testCaseManagerPage.isFolderAbsent(folderName),
                "Folder should be absent from list/tree after deletion: " + folderName);
        logPassStep("Folder successfully removed: " + folderName);

        logStep("TC_05 COMPLETED — Folder deleted and verified absent from UI");
    }
}
