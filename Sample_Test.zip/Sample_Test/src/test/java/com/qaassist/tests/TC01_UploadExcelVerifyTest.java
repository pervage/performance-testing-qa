package com.qaassist.tests;

import com.qaassist.base.BaseTest;
import com.qaassist.config.ConfigReader;
import com.qaassist.constants.Constants;
import com.qaassist.listeners.RetryAnalyzer;
import com.qaassist.listeners.TestListener;
import com.qaassist.pages.DashboardPage;
import com.qaassist.pages.LoginPage;
import com.qaassist.pages.TestCaseManagerPage;
import com.qaassist.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.File;
import java.util.Map;

/**
 * TC_01 — Upload Excel and Verify Test Case Details vs Excel (First Row)
 *
 * Description: Uploads Excel file, verifies folder created, opens first test case,
 * and validates fields match Excel first row.
 *
 * Pre-requisites:
 * - Valid SSO session
 * - Excel path configured (e.g., QA_ASSIST_EXCEL_PATH)
 * - Excel first row has columns: Module/Folder, Test Case Name, Pre-Conditions, Priority
 */
@Listeners(TestListener.class)
public class TC01_UploadExcelVerifyTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private TestCaseManagerPage testCaseManagerPage;

    private Map<String, String> expectedData;
    private String excelFilePath;

    @BeforeMethod(alwaysRun = true)
    public void initPages() {
        loginPage = new LoginPage(getDriver());
        excelFilePath = new File(ConfigReader.getExcelUploadPath()).getAbsolutePath();
    }

    @Test(priority = 1, groups = {"smoke", "regression"},
            description = "TC_01: Upload Excel and verify Test Case details match first row",
            retryAnalyzer = RetryAnalyzer.class)
    public void testUploadExcelAndVerifyTestCaseDetails() {
        createExtentTest("TC_01_UploadExcelVerifyTest",
                "Upload Excel file and verify test case fields match Excel first row");

        // Step 1: Load Excel and note expected values from first row
        logStep("Step 1: Loading expected values from Excel first row");
        expectedData = ExcelUtils.readFirstRow(excelFilePath, "TestCases");
        String expectedFolder = expectedData.get(Constants.COL_MODULE_FOLDER);
        String expectedTestCaseName = expectedData.get(Constants.COL_TEST_CASE_NAME);
        String expectedPreConditions = expectedData.get(Constants.COL_PRE_CONDITIONS);
        String expectedPriority = expectedData.get(Constants.COL_PRIORITY);
        String expectedTestCaseType = expectedData.get(Constants.COL_TEST_CASE_TYPE);

        Assert.assertNotNull(expectedFolder, "Module/Folder column should not be null in Excel");
        Assert.assertNotNull(expectedTestCaseName, "Test Case Name should not be null in Excel");
        logPassStep("Expected values captured from Excel first row");

        // Step 2: Launch QA Assist and login via SSO
        logStep("Step 2: Launching QA Assist with SSO authentication");
        dashboardPage = loginPage.loginWithSSOProfile(ConfigReader.getBaseUrl());
        Assert.assertTrue(dashboardPage.isDashboardDisplayed(), "Dashboard should be displayed after login");
        logPassStep("SSO login successful — Dashboard displayed");

        // Step 3: Navigate to Test Case Manager
        logStep("Step 3: Navigating to Test Case Manager");
        testCaseManagerPage = dashboardPage.navigateToTestCaseManager();
        logPassStep("Test Case Manager opened");

        // Step 4: Upload the Excel file
        logStep("Step 4: Uploading Excel file in Test Case Manager");
        testCaseManagerPage.uploadExcelFile(excelFilePath);
        Assert.assertTrue(testCaseManagerPage.isUploadSuccessful(),
                "Excel upload should complete successfully");
        logPassStep("Excel upload completed successfully");

        // Step 5: Verify folder name (Module/Folder) appears in UI
        logStep("Step 5: Verifying folder '" + expectedFolder + "' appears in UI");
        Assert.assertTrue(testCaseManagerPage.isFolderVisible(expectedFolder),
                "Folder '" + expectedFolder + "' should be visible in tree/list");
        logPassStep("Folder is visible: " + expectedFolder);

        // Step 6: Click the folder to expand
        logStep("Step 6: Clicking folder to expand and view test cases");
        testCaseManagerPage.clickFolder(expectedFolder);
        logPassStep("Folder expanded — test cases visible");

        // Step 7: Open the first test case under the folder
        logStep("Step 7: Opening first test case under the folder");
        testCaseManagerPage.openFirstTestCase();
        logPassStep("First test case details panel opened");

        // Step 8: Verify Test Case Name matches Excel
        logStep("Step 8: Verifying Test Case Name matches Excel");
        String actualTestCaseName = testCaseManagerPage.getTestCaseName();
        Assert.assertEquals(actualTestCaseName, expectedTestCaseName,
                "Test Case Name should match Excel. Expected: " + expectedTestCaseName
                        + " Actual: " + actualTestCaseName);
        logPassStep("Test Case Name matches: " + actualTestCaseName);

        // Step 9: Verify Pre-Conditions match Excel
        logStep("Step 9: Verifying Pre-Conditions match Excel");
        String actualPreConditions = testCaseManagerPage.getPreConditions();
        Assert.assertEquals(actualPreConditions, expectedPreConditions,
                "Pre-Conditions should match Excel. Expected: " + expectedPreConditions
                        + " Actual: " + actualPreConditions);
        logPassStep("Pre-Conditions match: " + actualPreConditions);

        // Step 10: Verify Priority matches Excel
        logStep("Step 10: Verifying Priority matches Excel");
        String actualPriority = testCaseManagerPage.getPriority();
        Assert.assertEquals(actualPriority, expectedPriority,
                "Priority should match Excel. Expected: " + expectedPriority
                        + " Actual: " + actualPriority);
        logPassStep("Priority matches: " + actualPriority);

        // Step 11: Verify Test Case Type matches Excel
        logStep("Step 11: Verifying Test Case Type matches Excel");
        String actualTestCaseType = testCaseManagerPage.getTestCaseType();
        Assert.assertEquals(actualTestCaseType, expectedTestCaseType,
                "Test Case Type should match Excel. Expected: " + expectedTestCaseType
                        + " Actual: " + actualTestCaseType);
        logPassStep("Test Case Type matches: " + actualTestCaseType);

        logStep("TC_01 COMPLETED — All test case fields match Excel first row");
    }
}
