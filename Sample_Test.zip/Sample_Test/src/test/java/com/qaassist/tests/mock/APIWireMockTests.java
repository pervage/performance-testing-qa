package com.qaassist.tests.mock;

import com.qaassist.api.*;
import com.qaassist.config.ConfigReader;
import com.qaassist.mock.WireMockSetup;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.*;

/**
 * WireMock-based API tests — positive, negative, and edge-case validations.
 * Removes external dependencies and produces consistent test data.
 *
 * These tests cover ALL APIs NOT used in integration tests to ensure
 * comprehensive API validation through mocking.
 */
@Test(groups = {"mock", "api"})
public class APIWireMockTests {

    private static final Logger logger = LogManager.getLogger(APIWireMockTests.class);

    private static final String MOCK_PROJECT_ID = "mock-project-001";
    private static final String MOCK_SUITE_ID = "mock-suite-001";
    private static final String MOCK_TC_ID = "tc-new-001";

    private ProjectInsightsAPI projectInsightsAPI;
    private TestSuiteAPI testSuiteAPI;
    private TestCaseAPI testCaseAPI;
    private DefectAPI defectAPI;

    @BeforeSuite(alwaysRun = true)
    public void setupWireMock() {
        ConfigReader.initConfig();
        WireMockSetup.startServer();
        logger.info("WireMock server started for API mock tests");
    }

    @AfterSuite(alwaysRun = true)
    public void tearDownWireMock() {
        WireMockSetup.stopServer();
        logger.info("WireMock server stopped");
    }

    @BeforeMethod(alwaysRun = true)
    public void resetAndInitAPIs() {
        WireMockSetup.resetStubs();
        String mockBaseUrl = WireMockSetup.getBaseUrl() + "/api/v1";
        projectInsightsAPI = new ProjectInsightsAPI(mockBaseUrl);
        testSuiteAPI = new TestSuiteAPI(mockBaseUrl);
        testCaseAPI = new TestCaseAPI(mockBaseUrl);
        defectAPI = new DefectAPI(mockBaseUrl);
    }

    // ══════════════════════════════════════════
    // POSITIVE TESTS
    // ══════════════════════════════════════════

    @Test(priority = 1, description = "Positive: Fetch project insights successfully")
    public void testGetProjectInsightsPositive() {
        WireMockSetup.stubGetProjectInsightsSuccess(MOCK_PROJECT_ID);

        Response response = projectInsightsAPI.getProjectInsights(MOCK_PROJECT_ID);
        Assert.assertEquals(response.getStatusCode(), 200, "Status should be 200");
        Assert.assertEquals(response.jsonPath().getString("projectName"), "HU_QE_EDGE");
        Assert.assertEquals(response.jsonPath().getString("status"), "Active");
        Assert.assertEquals(response.jsonPath().getInt("totalTestCases"), 150);
        logger.info("PASS: Project insights fetched successfully");
    }

    @Test(priority = 2, description = "Positive: Fetch test suites successfully")
    public void testGetTestSuitesPositive() {
        WireMockSetup.stubGetTestSuitesSuccess(MOCK_PROJECT_ID);

        Response response = testSuiteAPI.getTestSuites(MOCK_PROJECT_ID);
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.jsonPath().getList("testSuites").size() > 0,
                "Should return at least one test suite");
        logger.info("PASS: Test suites fetched successfully");
    }

    @Test(priority = 3, description = "Positive: Create test suite successfully")
    public void testCreateTestSuitePositive() {
        WireMockSetup.stubCreateTestSuiteSuccess(MOCK_PROJECT_ID);

        Response response = testSuiteAPI.createTestSuite(MOCK_PROJECT_ID, "New Suite", "Description");
        Assert.assertEquals(response.getStatusCode(), 201);
        Assert.assertNotNull(response.jsonPath().getString("suiteId"));
        logger.info("PASS: Test suite created successfully");
    }

    @Test(priority = 4, description = "Positive: Get test cases in suite")
    public void testGetTestCasesPositive() {
        WireMockSetup.stubGetTestCasesSuccess(MOCK_PROJECT_ID, MOCK_SUITE_ID);

        Response response = testCaseAPI.getTestCases(MOCK_PROJECT_ID, MOCK_SUITE_ID);
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.jsonPath().getList("testCases").size() == 2,
                "Should return 2 test cases");
        logger.info("PASS: Test cases fetched successfully");
    }

    @Test(priority = 5, description = "Positive: Add test case to suite")
    public void testAddTestCasePositive() {
        WireMockSetup.stubAddTestCaseSuccess(MOCK_PROJECT_ID, MOCK_SUITE_ID);

        Response response = testCaseAPI.addTestCase(MOCK_PROJECT_ID, MOCK_SUITE_ID,
                "New Test", "Description", "High");
        Assert.assertEquals(response.getStatusCode(), 201);
        Assert.assertNotNull(response.jsonPath().getString("testCaseId"));
        logger.info("PASS: Test case added successfully");
    }

    @Test(priority = 6, description = "Positive: Remove test case from suite")
    public void testRemoveTestCasePositive() {
        WireMockSetup.stubRemoveTestCaseSuccess(MOCK_PROJECT_ID, MOCK_SUITE_ID, MOCK_TC_ID);

        Response response = testCaseAPI.removeTestCase(MOCK_PROJECT_ID, MOCK_SUITE_ID, MOCK_TC_ID);
        Assert.assertEquals(response.getStatusCode(), 200);
        logger.info("PASS: Test case removed successfully");
    }

    @Test(priority = 7, description = "Positive: Trigger suite rerun")
    public void testTriggerRerunPositive() {
        WireMockSetup.stubTriggerRerunSuccess(MOCK_PROJECT_ID, MOCK_SUITE_ID);

        Response response = testSuiteAPI.triggerRerun(MOCK_PROJECT_ID, MOCK_SUITE_ID);
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertNotNull(response.jsonPath().getString("runId"));
        logger.info("PASS: Rerun triggered successfully");
    }

    @Test(priority = 8, description = "Positive: Create defect")
    public void testCreateDefectPositive() {
        WireMockSetup.stubCreateDefectSuccess(MOCK_PROJECT_ID);

        Response response = defectAPI.createDefect(MOCK_PROJECT_ID, "Bug Title",
                "Description", "High", "tc-001");
        Assert.assertEquals(response.getStatusCode(), 201);
        Assert.assertEquals(response.jsonPath().getString("status"), "Open");
        logger.info("PASS: Defect created successfully");
    }

    @Test(priority = 9, description = "Positive: Fetch defects")
    public void testGetDefectsPositive() {
        WireMockSetup.stubGetDefectsSuccess(MOCK_PROJECT_ID);

        Response response = defectAPI.getDefects(MOCK_PROJECT_ID);
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.jsonPath().getList("defects").size() > 0);
        logger.info("PASS: Defects fetched successfully");
    }

    @Test(priority = 10, description = "Positive: Fetch executions")
    public void testGetExecutionsPositive() {
        WireMockSetup.stubGetExecutionsSuccess(MOCK_PROJECT_ID);

        Response response = projectInsightsAPI.doGet("/projects/" + MOCK_PROJECT_ID + "/executions");
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.jsonPath().getList("executions").size() > 0);
        logger.info("PASS: Executions fetched successfully");
    }

    // ══════════════════════════════════════════
    // NEGATIVE TESTS
    // ══════════════════════════════════════════

    @Test(priority = 11, description = "Negative: Fetch non-existent project — 404")
    public void testGetProjectInsightsNotFound() {
        String invalidProject = "invalid-project-999";
        WireMockSetup.stubGetProjectInsightsNotFound(invalidProject);

        Response response = projectInsightsAPI.getProjectInsights(invalidProject);
        Assert.assertEquals(response.getStatusCode(), 404, "Should return 404 for non-existent project");
        Assert.assertEquals(response.jsonPath().getString("error"), "Project not found");
        logger.info("PASS: 404 returned for non-existent project");
    }

    @Test(priority = 12, description = "Negative: Create test suite with invalid data — 400")
    public void testCreateTestSuiteBadRequest() {
        WireMockSetup.stubCreateTestSuiteBadRequest(MOCK_PROJECT_ID);

        Response response = testSuiteAPI.createTestSuite(MOCK_PROJECT_ID, "", "");
        Assert.assertEquals(response.getStatusCode(), 400, "Should return 400 for bad request");
        Assert.assertEquals(response.jsonPath().getString("error"), "Bad Request");
        logger.info("PASS: 400 returned for bad request");
    }

    @Test(priority = 13, description = "Negative: Create duplicate defect — 409")
    public void testCreateDuplicateDefect() {
        WireMockSetup.stubCreateDefectDuplicate(MOCK_PROJECT_ID);

        Response response = defectAPI.createDefect(MOCK_PROJECT_ID, "Duplicate Bug",
                "Same bug", "High", "tc-001");
        Assert.assertEquals(response.getStatusCode(), 409, "Should return 409 for duplicate");
        Assert.assertNotNull(response.jsonPath().getString("existingDefectId"));
        logger.info("PASS: 409 returned for duplicate defect");
    }

    @Test(priority = 14, description = "Negative: Unauthorized access — 401")
    public void testGetProjectInsightsUnauthorized() {
        WireMockSetup.stubGetProjectInsightsUnauthorized(MOCK_PROJECT_ID);

        Response response = projectInsightsAPI.getProjectInsights(MOCK_PROJECT_ID);
        Assert.assertEquals(response.getStatusCode(), 401, "Should return 401 for unauthorized");
        Assert.assertEquals(response.jsonPath().getString("error"), "Unauthorized");
        logger.info("PASS: 401 returned for unauthorized access");
    }

    @Test(priority = 15, description = "Negative: Server error — 500")
    public void testGetProjectInsightsServerError() {
        WireMockSetup.stubGetProjectInsightsServerError(MOCK_PROJECT_ID);

        Response response = projectInsightsAPI.getProjectInsights(MOCK_PROJECT_ID);
        Assert.assertEquals(response.getStatusCode(), 500, "Should return 500 for server error");
        Assert.assertEquals(response.jsonPath().getString("error"), "Internal Server Error");
        logger.info("PASS: 500 returned for server error");
    }

    // ══════════════════════════════════════════
    // EDGE CASE TESTS
    // ══════════════════════════════════════════

    @Test(priority = 16, description = "Edge Case: Empty test suites list")
    public void testGetTestSuitesEmpty() {
        WireMockSetup.stubGetTestSuitesEmpty(MOCK_PROJECT_ID);

        Response response = testSuiteAPI.getTestSuites(MOCK_PROJECT_ID);
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertEquals(response.jsonPath().getList("testSuites").size(), 0,
                "Should return empty list");
        logger.info("PASS: Empty test suites list handled correctly");
    }

    @Test(priority = 17, description = "Edge Case: Large response payload")
    public void testCreateTestSuiteLargeResponse() {
        WireMockSetup.stubCreateTestSuiteLargeResponse(MOCK_PROJECT_ID);

        Response response = testSuiteAPI.createTestSuite(MOCK_PROJECT_ID, "Large Suite", "Test");
        Assert.assertEquals(response.getStatusCode(), 201);
        String description = response.jsonPath().getString("description");
        Assert.assertNotNull(description, "Description should not be null");
        Assert.assertTrue(description.length() > 1000, "Description should be large");
        logger.info("PASS: Large response handled correctly");
    }

    @Test(priority = 18, description = "Edge Case: Verify response content types")
    public void testResponseContentType() {
        WireMockSetup.stubGetProjectInsightsSuccess(MOCK_PROJECT_ID);

        Response response = projectInsightsAPI.getProjectInsights(MOCK_PROJECT_ID);
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.getContentType().contains("application/json"),
                "Content type should be JSON");
        logger.info("PASS: Response content type verified");
    }

    @Test(priority = 19, description = "Edge Case: Verify all positive stubs work together")
    public void testAllPositiveStubsIntegration() {
        WireMockSetup.setupPositiveStubs(MOCK_PROJECT_ID, MOCK_SUITE_ID);

        // Verify all endpoints respond correctly
        Assert.assertEquals(projectInsightsAPI.getProjectInsights(MOCK_PROJECT_ID).getStatusCode(), 200);
        Assert.assertEquals(testSuiteAPI.getTestSuites(MOCK_PROJECT_ID).getStatusCode(), 200);
        Assert.assertEquals(testSuiteAPI.createTestSuite(MOCK_PROJECT_ID, "s", "d").getStatusCode(), 201);
        Assert.assertEquals(testCaseAPI.getTestCases(MOCK_PROJECT_ID, MOCK_SUITE_ID).getStatusCode(), 200);
        Assert.assertEquals(testCaseAPI.addTestCase(MOCK_PROJECT_ID, MOCK_SUITE_ID, "t", "d", "H").getStatusCode(), 201);
        Assert.assertEquals(testSuiteAPI.triggerRerun(MOCK_PROJECT_ID, MOCK_SUITE_ID).getStatusCode(), 200);
        Assert.assertEquals(defectAPI.createDefect(MOCK_PROJECT_ID, "t", "d", "H", "tc1").getStatusCode(), 201);
        Assert.assertEquals(defectAPI.getDefects(MOCK_PROJECT_ID).getStatusCode(), 200);
        logger.info("PASS: All positive stubs integration verified");
    }
}
