# Test Resources Configuration
# This file is a placeholder. Actual Excel files (.xlsx) must be created manually
# or generated via a script. Place them in:
#   src/test/resources/testdata/QA_Assist_TestData.xlsx
#   src/test/resources/testdata/QA_Assist_Upload.xlsx
#
# Expected Excel Format (Sheet: "TestCases"):
#
# | Module/Folder | Test Case Name       | Pre-Conditions      | Priority | Test Case Type | Test Steps           | Expected Result     |
# |---------------|----------------------|---------------------|----------|----------------|----------------------|---------------------|
# | NopCommerce   | Login Functionality  | Valid SSO session    | High     | Functional     | Navigate to login    | Login page displayed|
# | NopCommerce   | Dashboard Validation | Valid SSO session    | Medium   | Functional     | Verify dashboard     | Dashboard loads     |
# | NopCommerce   | Search Products      | User is logged in   | High     | Functional     | Search for product   | Results displayed   |
#
# The framework reads this Excel using Apache POI (ExcelUtils.java)
