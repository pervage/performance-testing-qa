package com.qaassist.api;

import com.qaassist.constants.Constants;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

/**
 * API client for Test Case operations — add, remove, list test cases.
 */
public class TestCaseAPI extends BaseAPI {

    public TestCaseAPI() {
        super();
    }

    public TestCaseAPI(String baseUrl) {
        super(baseUrl);
    }

    /**
     * Get all test cases in a suite.
     */
    public Response getTestCases(String projectId, String suiteId) {
        String endpoint = buildEndpoint(Constants.API_TEST_CASES,
                "projectId", projectId,
                "suiteId", suiteId);
        logger.info("Fetching test cases for project: {}, suite: {}", projectId, suiteId);
        return doGet(endpoint);
    }

    /**
     * Add a test case to a suite.
     */
    public Response addTestCase(String projectId, String suiteId, String testCaseName,
                                String description, String priority) {
        String endpoint = buildEndpoint(Constants.API_ADD_TEST_CASE,
                "projectId", projectId,
                "suiteId", suiteId);
        Map<String, Object> body = new HashMap<>();
        body.put("testCaseName", testCaseName);
        body.put("description", description);
        body.put("priority", priority);
        logger.info("Adding test case: {} to suite: {}", testCaseName, suiteId);
        return doPost(endpoint, body);
    }

    /**
     * Remove a test case from a suite.
     */
    public Response removeTestCase(String projectId, String suiteId, String testCaseId) {
        String endpoint = buildEndpoint(Constants.API_REMOVE_TEST_CASE,
                "projectId", projectId,
                "suiteId", suiteId,
                "testCaseId", testCaseId);
        logger.info("Removing test case: {} from suite: {}", testCaseId, suiteId);
        return doDelete(endpoint);
    }

    /**
     * Extract test case ID from add test case response.
     */
    public String getTestCaseIdFromResponse(Response response) {
        return response.jsonPath().getString("testCaseId");
    }

    /**
     * Get the count of test cases from list response.
     */
    public int getTestCaseCount(Response response) {
        return response.jsonPath().getList("testCases").size();
    }
}
