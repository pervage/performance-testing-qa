package com.qaassist.api;

import com.qaassist.config.ConfigReader;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

/**
 * Base API class providing common REST operations using RestAssured.
 * All API classes extend this for a consistent request/response pattern.
 */
public abstract class BaseAPI {

    protected final Logger logger = LogManager.getLogger(this.getClass());
    protected final String baseUrl;
    protected final String authToken;

    protected BaseAPI() {
        ConfigReader.initConfig();
        this.baseUrl = ConfigReader.getApiBaseUrl();
        this.authToken = ConfigReader.getApiAuthToken();
    }

    /**
     * Constructor with custom base URL (e.g., for WireMock).
     */
    protected BaseAPI(String baseUrl) {
        this.baseUrl = baseUrl;
        this.authToken = ConfigReader.getApiAuthToken();
    }

    /**
     * Build a base request spec with auth and content type.
     */
    protected RequestSpecification getRequestSpec() {
        RequestSpecification spec = RestAssured.given()
                .baseUri(baseUrl)
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON);

        if (authToken != null && !authToken.isEmpty()) {
            spec.header("Authorization", "Bearer " + authToken);
        }

        return spec;
    }

    // ── GET ──

    protected Response doGet(String endpoint) {
        logger.info("GET {}{}", baseUrl, endpoint);
        Response response = getRequestSpec().get(endpoint);
        logResponse(response);
        return response;
    }

    protected Response doGet(String endpoint, Map<String, ?> queryParams) {
        logger.info("GET {}{} with params: {}", baseUrl, endpoint, queryParams);
        Response response = getRequestSpec().queryParams(queryParams).get(endpoint);
        logResponse(response);
        return response;
    }

    // ── POST ──

    protected Response doPost(String endpoint, Object body) {
        logger.info("POST {}{}", baseUrl, endpoint);
        Response response = getRequestSpec().body(body).post(endpoint);
        logResponse(response);
        return response;
    }

    protected Response doPost(String endpoint) {
        logger.info("POST {}{}", baseUrl, endpoint);
        Response response = getRequestSpec().post(endpoint);
        logResponse(response);
        return response;
    }

    // ── PUT ──

    protected Response doPut(String endpoint, Object body) {
        logger.info("PUT {}{}", baseUrl, endpoint);
        Response response = getRequestSpec().body(body).put(endpoint);
        logResponse(response);
        return response;
    }

    // ── PATCH ──

    protected Response doPatch(String endpoint, Object body) {
        logger.info("PATCH {}{}", baseUrl, endpoint);
        Response response = getRequestSpec().body(body).patch(endpoint);
        logResponse(response);
        return response;
    }

    // ── DELETE ──

    protected Response doDelete(String endpoint) {
        logger.info("DELETE {}{}", baseUrl, endpoint);
        Response response = getRequestSpec().delete(endpoint);
        logResponse(response);
        return response;
    }

    // ── Path Param Builder ──

    protected String buildEndpoint(String template, String... replacements) {
        String result = template;
        for (int i = 0; i < replacements.length; i += 2) {
            result = result.replace("{" + replacements[i] + "}", replacements[i + 1]);
        }
        return result;
    }

    // ── Response Logging ──

    private void logResponse(Response response) {
        logger.info("Response Status: {} {}", response.getStatusCode(), response.getStatusLine());
        if (logger.isDebugEnabled()) {
            logger.debug("Response Body: {}", response.getBody().asString());
        }
    }
}
