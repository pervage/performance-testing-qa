package com.qaassist.api;

import com.qaassist.constants.Constants;
import io.restassured.response.Response;

/**
 * API client for Project Insights operations.
 */
public class ProjectInsightsAPI extends BaseAPI {

    public ProjectInsightsAPI() {
        super();
    }

    public ProjectInsightsAPI(String baseUrl) {
        super(baseUrl);
    }

    /**
     * Fetch project insights/details for a given project ID.
     */
    public Response getProjectInsights(String projectId) {
        String endpoint = buildEndpoint(Constants.API_PROJECT_INSIGHTS,
                "projectId", projectId);
        logger.info("Fetching project insights for project: {}", projectId);
        return doGet(endpoint);
    }

    /**
     * Extract project name from insights response.
     */
    public String getProjectNameFromResponse(Response response) {
        return response.jsonPath().getString("projectName");
    }

    /**
     * Extract project status from insights response.
     */
    public String getProjectStatus(Response response) {
        return response.jsonPath().getString("status");
    }

    /**
     * Extract total test cases count from project insights.
     */
    public int getTotalTestCases(Response response) {
        return response.jsonPath().getInt("totalTestCases");
    }
}
