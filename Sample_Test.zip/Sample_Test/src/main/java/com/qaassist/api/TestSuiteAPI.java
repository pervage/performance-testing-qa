package com.qaassist.api;

import com.qaassist.constants.Constants;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

/**
 * API client for Test Suite operations — create, list, rerun.
 */
public class TestSuiteAPI extends BaseAPI {

    public TestSuiteAPI() {
        super();
    }

    public TestSuiteAPI(String baseUrl) {
        super(baseUrl);
    }

    /**
     * Get all test suites for a project.
     */
    public Response getTestSuites(String projectId) {
        String endpoint = buildEndpoint(Constants.API_TEST_SUITES,
                "projectId", projectId);
        logger.info("Fetching test suites for project: {}", projectId);
        return doGet(endpoint);
    }

    /**
     * Create a new test suite.
     */
    public Response createTestSuite(String projectId, String suiteName, String description) {
        String endpoint = buildEndpoint(Constants.API_TEST_SUITES,
                "projectId", projectId);
        Map<String, Object> body = new HashMap<>();
        body.put("suiteName", suiteName);
        body.put("description", description);
        logger.info("Creating test suite: {} for project: {}", suiteName, projectId);
        return doPost(endpoint, body);
    }

    /**
     * Trigger rerun for a specific suite (QE_rerun_id).
     */
    public Response triggerRerun(String projectId, String suiteId) {
        String endpoint = buildEndpoint(Constants.API_RERUN,
                "projectId", projectId,
                "suiteId", suiteId);
        logger.info("Triggering rerun for project: {}, suite: {}", projectId, suiteId);
        return doPost(endpoint);
    }

    /**
     * Get the run ID from rerun response.
     */
    public String getRunIdFromResponse(Response response) {
        return response.jsonPath().getString("runId");
    }

    /**
     * Get suite ID from creation response.
     */
    public String getSuiteIdFromResponse(Response response) {
        return response.jsonPath().getString("suiteId");
    }
}
