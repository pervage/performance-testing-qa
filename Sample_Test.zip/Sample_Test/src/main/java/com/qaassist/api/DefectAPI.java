package com.qaassist.api;

import com.qaassist.constants.Constants;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

/**
 * API client for Defect operations — create, list defects.
 */
public class DefectAPI extends BaseAPI {

    public DefectAPI() {
        super();
    }

    public DefectAPI(String baseUrl) {
        super(baseUrl);
    }

    /**
     * Create a defect for a project.
     */
    public Response createDefect(String projectId, String title, String description,
                                 String severity, String testCaseId) {
        String endpoint = buildEndpoint(Constants.API_DEFECTS,
                "projectId", projectId);
        Map<String, Object> body = new HashMap<>();
        body.put("title", title);
        body.put("description", description);
        body.put("severity", severity);
        body.put("testCaseId", testCaseId);
        logger.info("Creating defect for project: {}, title: {}", projectId, title);
        return doPost(endpoint, body);
    }

    /**
     * Get all defects for a project.
     */
    public Response getDefects(String projectId) {
        String endpoint = buildEndpoint(Constants.API_DEFECTS,
                "projectId", projectId);
        logger.info("Fetching defects for project: {}", projectId);
        return doGet(endpoint);
    }

    /**
     * Get defect ID from creation response.
     */
    public String getDefectIdFromResponse(Response response) {
        return response.jsonPath().getString("defectId");
    }

    /**
     * Get defect status from creation response.
     */
    public String getDefectStatus(Response response) {
        return response.jsonPath().getString("status");
    }
}
