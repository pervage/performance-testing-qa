package com.qaassist.base;

import com.qaassist.config.ConfigReader;
import com.qaassist.exceptions.FrameworkException;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.time.Duration;

/**
 * Manages WebDriver lifecycle with ThreadLocal for parallel execution support.
 * Supports Chrome, Firefox, Edge browsers in normal and headless modes.
 */
public class DriverManager {

    private static final Logger logger = LogManager.getLogger(DriverManager.class);
    private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

    private DriverManager() {
        throw new UnsupportedOperationException("DriverManager cannot be instantiated");
    }

    /**
     * Initialize a new WebDriver based on config/system settings.
     */
    public static void initDriver() {
        if (driverThreadLocal.get() != null) {
            logger.warn("Driver already initialized for this thread. Quitting existing driver first.");
            quitDriver();
        }

        String browser = ConfigReader.getBrowser().toLowerCase();
        boolean headless = ConfigReader.isHeadless();

        logger.info("Initializing {} browser (headless: {})", browser, headless);

        WebDriver driver;
        try {
            switch (browser) {
                case "chrome" -> driver = initChrome(headless);
                case "firefox" -> driver = initFirefox(headless);
                case "edge" -> driver = initEdge(headless);
                default -> throw new FrameworkException("Unsupported browser: " + browser);
            }
        } catch (Exception e) {
            String msg = "Failed to initialize WebDriver for browser: " + browser;
            logger.error(msg, e);
            throw new FrameworkException(msg, e);
        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(ConfigReader.getImplicitWait()));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(
                ConfigReader.getIntProperty("page.load.timeout", 60)));

        driverThreadLocal.set(driver);
        logger.info("WebDriver initialized successfully for thread: {}", Thread.currentThread().getId());
    }

    /**
     * Initialize Chrome with SSO profile support for authenticated sessions.
     */
    private static WebDriver initChrome(boolean headless) {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();

        if (headless) {
            options.addArguments("--headless=new");
        }

        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--remote-allow-origins=*");

        // SSO Chrome profile for authenticated sessions
        String chromeProfilePath = ConfigReader.getChromeProfilePath();
        if (chromeProfilePath != null && !chromeProfilePath.isEmpty()
                && !chromeProfilePath.equals("/path/to/chrome/profile")) {
            options.addArguments("--user-data-dir=" + chromeProfilePath);
            logger.info("Using Chrome profile for SSO: {}", chromeProfilePath);
        }

        return new ChromeDriver(options);
    }

    private static WebDriver initFirefox(boolean headless) {
        WebDriverManager.firefoxdriver().setup();
        FirefoxOptions options = new FirefoxOptions();
        if (headless) {
            options.addArguments("--headless");
        }
        return new FirefoxDriver(options);
    }

    private static WebDriver initEdge(boolean headless) {
        WebDriverManager.edgedriver().setup();
        EdgeOptions options = new EdgeOptions();
        if (headless) {
            options.addArguments("--headless=new");
        }
        options.addArguments("--start-maximized");
        return new EdgeDriver(options);
    }

    /**
     * Get the WebDriver instance for the current thread.
     */
    public static WebDriver getDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver == null) {
            throw new FrameworkException("WebDriver not initialized. Call initDriver() first.");
        }
        return driver;
    }

    /**
     * Quit and clean up the driver for the current thread.
     */
    public static void quitDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver != null) {
            try {
                driver.quit();
                logger.info("WebDriver quit successfully for thread: {}", Thread.currentThread().getId());
            } catch (Exception e) {
                logger.error("Error quitting WebDriver", e);
            } finally {
                driverThreadLocal.remove();
            }
        }
    }
}
