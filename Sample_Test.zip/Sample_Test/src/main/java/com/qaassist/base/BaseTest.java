package com.qaassist.base;

import com.qaassist.config.ConfigReader;
import com.qaassist.utils.ExtentReportManager;
import com.qaassist.utils.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

/**
 * Base test class providing common setup/teardown and utility access.
 * All test classes must extend this.
 */
public abstract class BaseTest {

    protected static final Logger logger = LogManager.getLogger(BaseTest.class);
    protected static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() {
        ConfigReader.initConfig();
        ExtentReportManager.initReport();
        logger.info("========== Test Suite Started ==========");
    }

    @BeforeMethod(alwaysRun = true)
    @Parameters({"browser", "headless"})
    public void setUp(@Optional("") String browser, @Optional("") String headless) {
        // Override config with TestNG parameters if provided
        if (browser != null && !browser.isEmpty()) {
            System.setProperty("browser", browser);
        }
        if (headless != null && !headless.isEmpty()) {
            System.setProperty("headless", headless);
        }

        DriverManager.initDriver();
        logger.info("Test setup completed. Browser launched.");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        try {
            if (result.getStatus() == ITestResult.FAILURE) {
                logger.error("TEST FAILED: {}", result.getName());
                captureFailureScreenshot(result.getName());
            } else if (result.getStatus() == ITestResult.SUCCESS) {
                logger.info("TEST PASSED: {}", result.getName());
            } else if (result.getStatus() == ITestResult.SKIP) {
                logger.warn("TEST SKIPPED: {}", result.getName());
            }
        } catch (Exception e) {
            logger.error("Error in tearDown", e);
        } finally {
            DriverManager.quitDriver();
            extentTest.remove();
        }
    }

    @AfterSuite(alwaysRun = true)
    public void afterSuite() {
        ExtentReportManager.flushReport();
        logger.info("========== Test Suite Completed ==========");
    }

    /**
     * Convenience to get current driver.
     */
    protected WebDriver getDriver() {
        return DriverManager.getDriver();
    }

    /**
     * Capture screenshot on success with a descriptive step name.
     */
    protected void captureSuccessScreenshot(String stepName) {
        if (ConfigReader.screenshotOnSuccess()) {
            String path = ScreenshotUtils.takeScreenshot(getDriver(), stepName);
            ExtentTest test = extentTest.get();
            if (test != null && path != null) {
                test.pass("Step passed: " + stepName,
                        com.aventstack.extentreports.MediaEntityBuilder
                                .createScreenCaptureFromPath(path).build());
            }
        }
    }

    /**
     * Capture screenshot on failure.
     */
    protected void captureFailureScreenshot(String testName) {
        if (ConfigReader.screenshotOnFailure()) {
            try {
                String path = ScreenshotUtils.takeScreenshot(getDriver(), "FAIL_" + testName);
                ExtentTest test = extentTest.get();
                if (test != null && path != null) {
                    test.fail("Test failed — screenshot captured",
                            com.aventstack.extentreports.MediaEntityBuilder
                                    .createScreenCaptureFromPath(path).build());
                }
            } catch (Exception e) {
                logger.error("Could not capture failure screenshot for: {}", testName, e);
            }
        }
    }

    /**
     * Create an ExtentTest for the current test method.
     */
    protected ExtentTest createExtentTest(String testName, String description) {
        ExtentTest test = ExtentReportManager.createTest(testName, description);
        extentTest.set(test);
        return test;
    }

    /**
     * Log info to both logger and extent report.
     */
    protected void logStep(String message) {
        logger.info(message);
        ExtentTest test = extentTest.get();
        if (test != null) {
            test.info(message);
        }
    }

    /**
     * Log pass step with optional screenshot.
     */
    protected void logPassStep(String message) {
        logger.info("PASS: {}", message);
        ExtentTest test = extentTest.get();
        if (test != null) {
            test.pass(message);
        }
        captureSuccessScreenshot(message.replaceAll("[^a-zA-Z0-9_-]", "_"));
    }

    /**
     * Log fail step.
     */
    protected void logFailStep(String message) {
        logger.error("FAIL: {}", message);
        ExtentTest test = extentTest.get();
        if (test != null) {
            test.fail(message);
        }
    }
}
