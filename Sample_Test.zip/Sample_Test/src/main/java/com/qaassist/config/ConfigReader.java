package com.qaassist.config;

import com.qaassist.constants.Constants;
import com.qaassist.exceptions.FrameworkException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Reads and provides access to configuration properties.
 * Supports system property overrides for CI/CD flexibility.
 */
public class ConfigReader {

    private static final Logger logger = LogManager.getLogger(ConfigReader.class);
    private static Properties properties;
    private static final Object LOCK = new Object();

    private ConfigReader() {
        throw new UnsupportedOperationException("ConfigReader cannot be instantiated");
    }

    /**
     * Initializes properties from the config file. Thread-safe singleton loading.
     */
    public static void initConfig() {
        if (properties == null) {
            synchronized (LOCK) {
                if (properties == null) {
                    properties = new Properties();
                    try (FileInputStream fis = new FileInputStream(Constants.CONFIG_FILE_PATH)) {
                        properties.load(fis);
                        logger.info("Configuration loaded successfully from {}", Constants.CONFIG_FILE_PATH);
                    } catch (IOException e) {
                        String msg = "Failed to load config file: " + Constants.CONFIG_FILE_PATH;
                        logger.error(msg, e);
                        throw new FrameworkException(msg, e);
                    }
                }
            }
        }
    }

    /**
     * Returns property value. System properties override file properties.
     */
    public static String getProperty(String key) {
        initConfig();
        String systemValue = System.getProperty(key);
        if (systemValue != null && !systemValue.isEmpty()) {
            return systemValue;
        }
        String value = properties.getProperty(key);
        if (value == null) {
            logger.warn("Property '{}' not found in configuration", key);
        }
        return value;
    }

    /**
     * Returns property value with a default fallback.
     */
    public static String getProperty(String key, String defaultValue) {
        String value = getProperty(key);
        return (value != null) ? value : defaultValue;
    }

    /**
     * Returns property value as integer.
     */
    public static int getIntProperty(String key, int defaultValue) {
        String value = getProperty(key);
        if (value == null) return defaultValue;
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            logger.warn("Invalid integer for property '{}': {}. Using default: {}", key, value, defaultValue);
            return defaultValue;
        }
    }

    /**
     * Returns property value as boolean.
     */
    public static boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = getProperty(key);
        if (value == null) return defaultValue;
        return Boolean.parseBoolean(value.trim());
    }

    // ── Convenience Accessors ──

    public static String getBaseUrl() {
        return getProperty("app.base.url");
    }

    public static String getApiBaseUrl() {
        return getProperty("api.base.url");
    }

    public static String getBrowser() {
        return getProperty("browser", "chrome");
    }

    public static boolean isHeadless() {
        return getBooleanProperty("headless", false);
    }

    public static int getImplicitWait() {
        return getIntProperty("implicit.wait", Constants.DEFAULT_IMPLICIT_WAIT);
    }

    public static int getExplicitWait() {
        return getIntProperty("explicit.wait", Constants.DEFAULT_EXPLICIT_WAIT);
    }

    public static String getExcelTestDataPath() {
        return getProperty("excel.testdata.path");
    }

    public static String getExcelUploadPath() {
        return getProperty("excel.upload.path");
    }

    public static String getApiAuthToken() {
        return getProperty("api.auth.token");
    }

    public static String getProjectName() {
        return getProperty("project.name", Constants.PROJECT_HU_QE_EDGE);
    }

    public static String getProjectId() {
        return getProperty("project.id");
    }

    public static boolean isQTestEnabled() {
        return getBooleanProperty("qtest.enabled", false);
    }

    public static String getQTestBaseUrl() {
        return getProperty("qtest.base.url");
    }

    public static String getQTestApiToken() {
        return getProperty("qtest.api.token");
    }

    public static String getQTestProjectId() {
        return getProperty("qtest.project.id");
    }

    public static String getScreenshotPath() {
        return getProperty("screenshot.path", Constants.SCREENSHOT_DIR);
    }

    public static boolean screenshotOnSuccess() {
        return getBooleanProperty("screenshot.on.success", true);
    }

    public static boolean screenshotOnFailure() {
        return getBooleanProperty("screenshot.on.failure", true);
    }

    public static String getChromeProfilePath() {
        return getProperty("sso.chrome.profile.path");
    }

    public static int getWireMockPort() {
        return getIntProperty("wiremock.port", 8089);
    }

    public static int getRetryCount() {
        return getIntProperty("retry.count", 1);
    }
}
