package com.qaassist.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Utility to generate sample test data Excel files for the framework.
 * Run this class's main method to create the required .xlsx files.
 */
public class TestDataGenerator {

    public static void main(String[] args) throws IOException {
        generateTestDataFile("src/test/resources/testdata/QA_Assist_TestData.xlsx");
        generateUploadFile("src/test/resources/testdata/QA_Assist_Upload.xlsx");
        System.out.println("Test data Excel files generated successfully!");
    }

    private static void generateTestDataFile(String filePath) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("TestCases");

            // Header row
            Row header = sheet.createRow(0);
            String[] headers = {
                    "Module/Folder", "Test Case Name", "Pre-Conditions",
                    "Priority", "Test Case Type", "Test Steps", "Expected Result"
            };
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            for (int i = 0; i < headers.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Data rows
            String[][] data = {
                    {"NopCommerce", "Login Functionality Test", "Valid SSO session available",
                            "High", "Functional", "Navigate to login page and enter credentials",
                            "User is logged in successfully"},
                    {"NopCommerce", "Dashboard Validation Test", "User is logged in",
                            "Medium", "Functional", "Verify dashboard elements are displayed",
                            "Dashboard loads with all widgets"},
                    {"NopCommerce", "Search Products Test", "User is on dashboard",
                            "High", "Functional", "Search for a product using search bar",
                            "Search results are displayed correctly"},
                    {"NopCommerce", "Add to Cart Test", "Product is available",
                            "High", "Functional", "Add product to shopping cart",
                            "Product is added to cart successfully"},
                    {"NopCommerce", "Checkout Flow Test", "Cart has items",
                            "Critical", "E2E", "Complete checkout process",
                            "Order is placed successfully"}
            };

            for (int i = 0; i < data.length; i++) {
                Row row = sheet.createRow(i + 1);
                for (int j = 0; j < data[i].length; j++) {
                    row.createCell(j).setCellValue(data[i][j]);
                }
            }

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Write to file
            try (FileOutputStream fos = new FileOutputStream(filePath)) {
                workbook.write(fos);
            }
        }
    }

    private static void generateUploadFile(String filePath) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("TestCases");

            Row header = sheet.createRow(0);
            String[] headers = {
                    "Module/Folder", "Test Case Name", "Pre-Conditions",
                    "Priority", "Test Case Type", "Test Steps", "Expected Result"
            };

            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            for (int i = 0; i < headers.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            String[][] data = {
                    {"NopCommerce", "Login Functionality Test", "Valid SSO session available",
                            "High", "Functional", "Navigate to login page",
                            "Login page is displayed"},
                    {"NopCommerce", "Registration Test", "No existing account",
                            "Medium", "Functional", "Fill registration form",
                            "User is registered"},
                    {"NopCommerce", "Password Reset Test", "Valid email configured",
                            "Low", "Functional", "Click forgot password",
                            "Reset email sent"}
            };

            for (int i = 0; i < data.length; i++) {
                Row row = sheet.createRow(i + 1);
                for (int j = 0; j < data[i].length; j++) {
                    row.createCell(j).setCellValue(data[i][j]);
                }
            }

            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            try (FileOutputStream fos = new FileOutputStream(filePath)) {
                workbook.write(fos);
            }
        }
    }
}
