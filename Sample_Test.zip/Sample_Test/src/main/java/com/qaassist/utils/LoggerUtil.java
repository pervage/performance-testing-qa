package com.qaassist.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Centralized logger utility providing a convenient wrapper around Log4j2.
 */
public class LoggerUtil {

    private LoggerUtil() {
        throw new UnsupportedOperationException("LoggerUtil cannot be instantiated");
    }

    public static Logger getLogger(Class<?> clazz) {
        return LogManager.getLogger(clazz);
    }

    public static void info(Logger logger, String message, Object... args) {
        logger.info(message, args);
    }

    public static void debug(Logger logger, String message, Object... args) {
        logger.debug(message, args);
    }

    public static void warn(Logger logger, String message, Object... args) {
        logger.warn(message, args);
    }

    public static void error(Logger logger, String message, Object... args) {
        logger.error(message, args);
    }

    public static void error(Logger logger, String message, Throwable throwable) {
        logger.error(message, throwable);
    }
}
