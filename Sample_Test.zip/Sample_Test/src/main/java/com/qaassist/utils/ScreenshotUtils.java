package com.qaassist.utils;

import com.qaassist.config.ConfigReader;
import com.qaassist.constants.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Handles screenshot capture for test evidence.
 * Captures on success (every page) and on failure (mandatory).
 */
public class ScreenshotUtils {

    private static final Logger logger = LogManager.getLogger(ScreenshotUtils.class);
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    private ScreenshotUtils() {
        throw new UnsupportedOperationException("ScreenshotUtils cannot be instantiated");
    }

    /**
     * Take a screenshot and save it to the configured path.
     *
     * @param driver   WebDriver instance
     * @param stepName descriptive name for the screenshot
     * @return absolute path to the screenshot file, or null on failure
     */
    public static String takeScreenshot(WebDriver driver, String stepName) {
        if (driver == null) {
            logger.warn("Cannot take screenshot — driver is null");
            return null;
        }

        try {
            String screenshotDir = ConfigReader.getScreenshotPath();
            Path dirPath = Paths.get(screenshotDir);
            if (!Files.exists(dirPath)) {
                Files.createDirectories(dirPath);
            }

            String timestamp = LocalDateTime.now().format(FORMATTER);
            String sanitizedName = stepName.replaceAll("[^a-zA-Z0-9_-]", "_");
            String fileName = sanitizedName + "_" + timestamp + "." + Constants.SCREENSHOT_FORMAT;

            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Path destPath = dirPath.resolve(fileName);
            Files.copy(srcFile.toPath(), destPath, StandardCopyOption.REPLACE_EXISTING);

            String absolutePath = destPath.toAbsolutePath().toString();
            logger.info("Screenshot saved: {}", absolutePath);
            return absolutePath;

        } catch (IOException e) {
            logger.error("Failed to capture screenshot for step: {}", stepName, e);
            return null;
        } catch (Exception e) {
            logger.error("Unexpected error capturing screenshot for step: {}", stepName, e);
            return null;
        }
    }

    /**
     * Take screenshot and return as Base64 (for embedding in reports).
     */
    public static String takeScreenshotAsBase64(WebDriver driver) {
        if (driver == null) return null;
        try {
            return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
        } catch (Exception e) {
            logger.error("Failed to capture Base64 screenshot", e);
            return null;
        }
    }
}
