package com.qaassist.utils;

import com.qaassist.exceptions.FrameworkException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

/**
 * Utility class for reading test data from Excel (.xlsx) files.
 * Supports reading by row index, row range, and as List of Maps.
 */
public class ExcelUtils {

    private static final Logger logger = LogManager.getLogger(ExcelUtils.class);

    private ExcelUtils() {
        throw new UnsupportedOperationException("ExcelUtils cannot be instantiated");
    }

    /**
     * Reads all rows from the specified sheet as List of Maps (header → value).
     */
    public static List<Map<String, String>> readSheetData(String filePath, String sheetName) {
        List<Map<String, String>> data = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new FrameworkException("Sheet '" + sheetName + "' not found in: " + filePath);
            }

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new FrameworkException("Header row is empty in sheet: " + sheetName);
            }

            List<String> headers = new ArrayList<>();
            for (Cell cell : headerRow) {
                headers.add(getCellValueAsString(cell).trim());
            }

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                Map<String, String> rowData = new LinkedHashMap<>();
                for (int j = 0; j < headers.size(); j++) {
                    Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    rowData.put(headers.get(j), getCellValueAsString(cell).trim());
                }
                data.add(rowData);
            }

            logger.info("Read {} rows from sheet '{}' in file: {}", data.size(), sheetName, filePath);
        } catch (IOException e) {
            throw new FrameworkException("Failed to read Excel file: " + filePath, e);
        }
        return data;
    }

    /**
     * Reads a specific row (0-based data row index, excluding header) as a Map.
     */
    public static Map<String, String> readRow(String filePath, String sheetName, int dataRowIndex) {
        List<Map<String, String>> allData = readSheetData(filePath, sheetName);
        if (dataRowIndex < 0 || dataRowIndex >= allData.size()) {
            throw new FrameworkException("Row index " + dataRowIndex + " out of bounds. Total data rows: " + allData.size());
        }
        return allData.get(dataRowIndex);
    }

    /**
     * Reads the first data row from the specified sheet.
     */
    public static Map<String, String> readFirstRow(String filePath, String sheetName) {
        return readRow(filePath, sheetName, 0);
    }

    /**
     * Gets a specific cell value by row and column name.
     */
    public static String getCellValue(String filePath, String sheetName, int dataRowIndex, String columnName) {
        Map<String, String> rowData = readRow(filePath, sheetName, dataRowIndex);
        if (!rowData.containsKey(columnName)) {
            throw new FrameworkException("Column '" + columnName + "' not found in sheet: " + sheetName);
        }
        return rowData.get(columnName);
    }

    /**
     * Returns the number of data rows (excluding header).
     */
    public static int getRowCount(String filePath, String sheetName) {
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) return 0;
            return sheet.getLastRowNum(); // header is row 0
        } catch (IOException e) {
            throw new FrameworkException("Failed to read Excel file: " + filePath, e);
        }
    }

    /**
     * Returns all sheet names from the workbook.
     */
    public static List<String> getSheetNames(String filePath) {
        List<String> names = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                names.add(workbook.getSheetName(i));
            }
        } catch (IOException e) {
            throw new FrameworkException("Failed to read Excel file: " + filePath, e);
        }
        return names;
    }

    /**
     * Converts Cell value to String regardless of cell type.
     */
    private static String getCellValueAsString(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue();
            case NUMERIC -> {
                if (DateUtil.isCellDateFormatted(cell)) {
                    yield cell.getDateCellValue().toString();
                }
                double numVal = cell.getNumericCellValue();
                if (numVal == Math.floor(numVal)) {
                    yield String.valueOf((long) numVal);
                }
                yield String.valueOf(numVal);
            }
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            case FORMULA -> {
                try {
                    yield cell.getStringCellValue();
                } catch (Exception e) {
                    yield String.valueOf(cell.getNumericCellValue());
                }
            }
            case BLANK -> "";
            default -> "";
        };
    }

    /**
     * Reads data for TestNG DataProvider (Object[][]).
     */
    public static Object[][] readAsDataProvider(String filePath, String sheetName) {
        List<Map<String, String>> data = readSheetData(filePath, sheetName);
        Object[][] result = new Object[data.size()][1];
        for (int i = 0; i < data.size(); i++) {
            result[i][0] = data.get(i);
        }
        return result;
    }
}
