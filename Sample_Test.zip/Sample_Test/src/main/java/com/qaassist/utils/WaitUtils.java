package com.qaassist.utils;

import com.qaassist.constants.Constants;
import com.qaassist.exceptions.FrameworkException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * Centralized wait utility using explicit waits.
 */
public class WaitUtils {

    private static final Logger logger = LogManager.getLogger(WaitUtils.class);

    private WaitUtils() {
        throw new UnsupportedOperationException("WaitUtils cannot be instantiated");
    }

    private static WebDriverWait getWait(WebDriver driver, int timeoutSeconds) {
        return new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds),
                Duration.ofMillis(Constants.POLLING_INTERVAL_MS));
    }

    public static WebElement waitForElementVisible(WebDriver driver, By locator, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds).until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            throw new FrameworkException("Element not visible within " + timeoutSeconds + "s: " + locator, e);
        }
    }

    public static WebElement waitForElementVisible(WebDriver driver, By locator) {
        return waitForElementVisible(driver, locator, Constants.DEFAULT_EXPLICIT_WAIT);
    }

    public static WebElement waitForElementClickable(WebDriver driver, By locator, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds).until(ExpectedConditions.elementToBeClickable(locator));
        } catch (TimeoutException e) {
            throw new FrameworkException("Element not clickable within " + timeoutSeconds + "s: " + locator, e);
        }
    }

    public static WebElement waitForElementClickable(WebDriver driver, By locator) {
        return waitForElementClickable(driver, locator, Constants.DEFAULT_EXPLICIT_WAIT);
    }

    public static WebElement waitForElementPresent(WebDriver driver, By locator, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds).until(ExpectedConditions.presenceOfElementLocated(locator));
        } catch (TimeoutException e) {
            throw new FrameworkException("Element not present within " + timeoutSeconds + "s: " + locator, e);
        }
    }

    public static WebElement waitForElementPresent(WebDriver driver, By locator) {
        return waitForElementPresent(driver, locator, Constants.DEFAULT_EXPLICIT_WAIT);
    }

    public static List<WebElement> waitForAllElementsVisible(WebDriver driver, By locator, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
        } catch (TimeoutException e) {
            throw new FrameworkException("Elements not visible within " + timeoutSeconds + "s: " + locator, e);
        }
    }

    public static List<WebElement> waitForAllElementsVisible(WebDriver driver, By locator) {
        return waitForAllElementsVisible(driver, locator, Constants.DEFAULT_EXPLICIT_WAIT);
    }

    public static boolean waitForElementInvisible(WebDriver driver, By locator, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds).until(ExpectedConditions.invisibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            return false;
        }
    }

    public static boolean waitForTextInElement(WebDriver driver, By locator, String text, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds)
                    .until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
        } catch (TimeoutException e) {
            return false;
        }
    }

    public static void waitForPageLoad(WebDriver driver, int timeoutSeconds) {
        try {
            getWait(driver, timeoutSeconds).until(d ->
                    ((JavascriptExecutor) d).executeScript("return document.readyState").equals("complete"));
        } catch (TimeoutException e) {
            logger.warn("Page did not fully load within {}s", timeoutSeconds);
        }
    }

    public static void waitForPageLoad(WebDriver driver) {
        waitForPageLoad(driver, Constants.DEFAULT_PAGE_LOAD_TIMEOUT);
    }

    /**
     * Wait until a specific URL fragment is present.
     */
    public static boolean waitForUrlContains(WebDriver driver, String urlFragment, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds).until(ExpectedConditions.urlContains(urlFragment));
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Wait for the element to become stale (removed from DOM).
     */
    public static boolean waitForElementStale(WebDriver driver, WebElement element, int timeoutSeconds) {
        try {
            return getWait(driver, timeoutSeconds).until(ExpectedConditions.stalenessOf(element));
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Static wait (use sparingly).
     */
    public static void staticWait(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.warn("Static wait interrupted");
        }
    }
}
