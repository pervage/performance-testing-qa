package com.qaassist.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.qaassist.config.ConfigReader;
import com.qaassist.constants.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Manages ExtentReports lifecycle for HTML test reporting.
 * Thread-safe for parallel execution support.
 */
public class ExtentReportManager {

    private static final Logger logger = LogManager.getLogger(ExtentReportManager.class);
    private static ExtentReports extent;
    private static final Object LOCK = new Object();

    private ExtentReportManager() {
        throw new UnsupportedOperationException("ExtentReportManager cannot be instantiated");
    }

    /**
     * Initialize the ExtentReports instance with SparkReporter.
     */
    public static void initReport() {
        if (extent == null) {
            synchronized (LOCK) {
                if (extent == null) {
                    String reportDir = ConfigReader.getProperty("extent.report.path", Constants.EXTENT_REPORT_DIR);
                    File dir = new File(reportDir);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }

                    String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
                    String reportPath = reportDir + "TestReport_" + timestamp + ".html";

                    ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
                    sparkReporter.config().setDocumentTitle(Constants.REPORT_TITLE);
                    sparkReporter.config().setReportName(Constants.REPORT_NAME);
                    sparkReporter.config().setTheme(Theme.STANDARD);
                    sparkReporter.config().setEncoding("UTF-8");
                    sparkReporter.config().setTimeStampFormat("yyyy-MM-dd HH:mm:ss");

                    extent = new ExtentReports();
                    extent.attachReporter(sparkReporter);
                    extent.setSystemInfo("Environment", ConfigReader.getProperty("app.environment", "UAT"));
                    extent.setSystemInfo("Browser", ConfigReader.getBrowser());
                    extent.setSystemInfo("OS", System.getProperty("os.name"));
                    extent.setSystemInfo("Java Version", System.getProperty("java.version"));
                    extent.setSystemInfo("User", System.getProperty("user.name"));

                    logger.info("ExtentReport initialized at: {}", reportPath);
                }
            }
        }
    }

    /**
     * Create a new test entry in the report.
     */
    public static synchronized ExtentTest createTest(String testName, String description) {
        if (extent == null) {
            initReport();
        }
        return extent.createTest(testName, description);
    }

    /**
     * Create a test node under a parent test (for grouping).
     */
    public static synchronized ExtentTest createTestNode(ExtentTest parentTest, String nodeName) {
        return parentTest.createNode(nodeName);
    }

    /**
     * Flush the report (must be called at suite end).
     */
    public static void flushReport() {
        if (extent != null) {
            extent.flush();
            logger.info("ExtentReport flushed successfully");
        }
    }

    /**
     * Get the underlying ExtentReports instance.
     */
    public static ExtentReports getExtent() {
        if (extent == null) {
            initReport();
        }
        return extent;
    }
}
