package com.qaassist.mock;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.qaassist.config.ConfigReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

/**
 * WireMock server setup for API mocking.
 * Removes external dependencies and provides consistent test data.
 */
public class WireMockSetup {

    private static final Logger logger = LogManager.getLogger(WireMockSetup.class);
    private static WireMockServer wireMockServer;

    private WireMockSetup() {
        throw new UnsupportedOperationException("WireMockSetup cannot be instantiated");
    }

    /**
     * Start the WireMock server.
     */
    public static void startServer() {
        int port = ConfigReader.getWireMockPort();
        wireMockServer = new WireMockServer(WireMockConfiguration.options().port(port));
        wireMockServer.start();
        WireMock.configureFor("localhost", port);
        logger.info("WireMock server started on port: {}", port);
    }

    /**
     * Stop the WireMock server.
     */
    public static void stopServer() {
        if (wireMockServer != null && wireMockServer.isRunning()) {
            wireMockServer.stop();
            logger.info("WireMock server stopped");
        }
    }

    /**
     * Reset all stubs.
     */
    public static void resetStubs() {
        if (wireMockServer != null) {
            wireMockServer.resetAll();
        }
    }

    /**
     * Get the base URL for the WireMock server.
     */
    public static String getBaseUrl() {
        return "http://localhost:" + ConfigReader.getWireMockPort();
    }

    // ══════════════════════════════════════════════
    // STUB DEFINITIONS — Positive Scenarios
    // ══════════════════════════════════════════════

    /**
     * Stub: GET project insights — success.
     */
    public static void stubGetProjectInsightsSuccess(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/insights"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "projectId": "%s",
                                    "projectName": "HU_QE_EDGE",
                                    "status": "Active",
                                    "totalTestCases": 150,
                                    "totalTestSuites": 12,
                                    "environment": "UAT",
                                    "lastUpdated": "2026-03-06T10:00:00Z"
                                }
                                """.formatted(projectId))));
        logger.info("Stubbed GET project insights (success) for project: {}", projectId);
    }

    /**
     * Stub: GET test suites — success.
     */
    public static void stubGetTestSuitesSuccess(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "testSuites": [
                                        {
                                            "suiteId": "suite-001",
                                            "suiteName": "Smoke Test Suite",
                                            "status": "Completed",
                                            "totalCases": 25
                                        },
                                        {
                                            "suiteId": "suite-002",
                                            "suiteName": "Regression Suite",
                                            "status": "In Progress",
                                            "totalCases": 80
                                        }
                                    ]
                                }
                                """)));
        logger.info("Stubbed GET test suites (success) for project: {}", projectId);
    }

    /**
     * Stub: POST create test suite — success.
     */
    public static void stubCreateTestSuiteSuccess(String projectId) {
        stubFor(post(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites"))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "suiteId": "suite-new-001",
                                    "suiteName": "Mock Created Suite",
                                    "status": "Created",
                                    "message": "Test suite created successfully"
                                }
                                """)));
        logger.info("Stubbed POST create test suite (success) for project: {}", projectId);
    }

    /**
     * Stub: GET test cases in suite — success.
     */
    public static void stubGetTestCasesSuccess(String projectId, String suiteId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites/" + suiteId + "/test-cases"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "testCases": [
                                        {
                                            "testCaseId": "tc-001",
                                            "testCaseName": "Login Test",
                                            "priority": "High",
                                            "status": "Passed"
                                        },
                                        {
                                            "testCaseId": "tc-002",
                                            "testCaseName": "Dashboard Verification",
                                            "priority": "Medium",
                                            "status": "Failed"
                                        }
                                    ]
                                }
                                """)));
    }

    /**
     * Stub: POST add test case — success.
     */
    public static void stubAddTestCaseSuccess(String projectId, String suiteId) {
        stubFor(post(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites/" + suiteId + "/test-cases"))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "testCaseId": "tc-new-001",
                                    "testCaseName": "Mock Added Test Case",
                                    "message": "Test case added successfully"
                                }
                                """)));
    }

    /**
     * Stub: DELETE remove test case — success.
     */
    public static void stubRemoveTestCaseSuccess(String projectId, String suiteId, String testCaseId) {
        stubFor(delete(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites/" + suiteId + "/test-cases/" + testCaseId))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "message": "Test case removed successfully",
                                    "testCaseId": "%s"
                                }
                                """.formatted(testCaseId))));
    }

    /**
     * Stub: POST trigger rerun — success.
     */
    public static void stubTriggerRerunSuccess(String projectId, String suiteId) {
        stubFor(post(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites/" + suiteId + "/rerun"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "runId": "run-12345",
                                    "status": "Started",
                                    "message": "Execution triggered successfully"
                                }
                                """)));
    }

    /**
     * Stub: POST create defect — success.
     */
    public static void stubCreateDefectSuccess(String projectId) {
        stubFor(post(urlPathEqualTo("/api/v1/projects/" + projectId + "/defects"))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "defectId": "DEF-001",
                                    "status": "Open",
                                    "message": "Defect created successfully"
                                }
                                """)));
    }

    /**
     * Stub: GET defects — success.
     */
    public static void stubGetDefectsSuccess(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/defects"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "defects": [
                                        {
                                            "defectId": "DEF-001",
                                            "title": "Login page error",
                                            "severity": "High",
                                            "status": "Open"
                                        }
                                    ]
                                }
                                """)));
    }

    /**
     * Stub: GET executions — success.
     */
    public static void stubGetExecutionsSuccess(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/executions"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "executions": [
                                        {
                                            "executionId": "exec-001",
                                            "suiteName": "Smoke Suite",
                                            "totalCases": 10,
                                            "passed": 8,
                                            "failed": 2,
                                            "inProgress": 0
                                        }
                                    ]
                                }
                                """)));
    }

    // ══════════════════════════════════════════════
    // STUB DEFINITIONS — Negative Scenarios
    // ══════════════════════════════════════════════

    /**
     * Stub: GET project insights — 404 Not Found.
     */
    public static void stubGetProjectInsightsNotFound(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/insights"))
                .willReturn(aResponse()
                        .withStatus(404)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "error": "Project not found",
                                    "message": "No project found with ID: %s"
                                }
                                """.formatted(projectId))));
    }

    /**
     * Stub: POST create test suite — 400 Bad Request.
     */
    public static void stubCreateTestSuiteBadRequest(String projectId) {
        stubFor(post(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites"))
                .willReturn(aResponse()
                        .withStatus(400)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "error": "Bad Request",
                                    "message": "Suite name is required"
                                }
                                """)));
    }

    /**
     * Stub: POST create defect — 409 Conflict (duplicate).
     */
    public static void stubCreateDefectDuplicate(String projectId) {
        stubFor(post(urlPathEqualTo("/api/v1/projects/" + projectId + "/defects"))
                .willReturn(aResponse()
                        .withStatus(409)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "error": "Conflict",
                                    "message": "Duplicate defect detected",
                                    "existingDefectId": "DEF-001"
                                }
                                """)));
    }

    /**
     * Stub: GET project insights — 401 Unauthorized.
     */
    public static void stubGetProjectInsightsUnauthorized(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/insights"))
                .willReturn(aResponse()
                        .withStatus(401)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "error": "Unauthorized",
                                    "message": "Invalid or expired token"
                                }
                                """)));
    }

    /**
     * Stub: GET project insights — 500 Internal Server Error.
     */
    public static void stubGetProjectInsightsServerError(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/insights"))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "error": "Internal Server Error",
                                    "message": "An unexpected error occurred"
                                }
                                """)));
    }

    // ══════════════════════════════════════════════
    // STUB DEFINITIONS — Edge Case Scenarios
    // ══════════════════════════════════════════════

    /**
     * Stub: GET test suites — empty list.
     */
    public static void stubGetTestSuitesEmpty(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "testSuites": []
                                }
                                """)));
    }

    /**
     * Stub: GET project insights — slow response (timeout simulation).
     */
    public static void stubGetProjectInsightsTimeout(String projectId) {
        stubFor(get(urlPathEqualTo("/api/v1/projects/" + projectId + "/insights"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withFixedDelay(35000) // 35 second delay
                        .withHeader("Content-Type", "application/json")
                        .withBody("{}")));
    }

    /**
     * Stub: POST create test suite with large payload response.
     */
    public static void stubCreateTestSuiteLargeResponse(String projectId) {
        StringBuilder largeDescription = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            largeDescription.append("Test case ").append(i).append(" description. ");
        }
        stubFor(post(urlPathEqualTo("/api/v1/projects/" + projectId + "/test-suites"))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    "suiteId": "suite-large",
                                    "suiteName": "Large Suite",
                                    "description": "%s"
                                }
                                """.formatted(largeDescription.toString()))));
    }

    /**
     * Setup all positive stubs for a given project.
     */
    public static void setupPositiveStubs(String projectId, String suiteId) {
        stubGetProjectInsightsSuccess(projectId);
        stubGetTestSuitesSuccess(projectId);
        stubCreateTestSuiteSuccess(projectId);
        stubGetTestCasesSuccess(projectId, suiteId);
        stubAddTestCaseSuccess(projectId, suiteId);
        stubTriggerRerunSuccess(projectId, suiteId);
        stubCreateDefectSuccess(projectId);
        stubGetDefectsSuccess(projectId);
        stubGetExecutionsSuccess(projectId);
        logger.info("All positive stubs configured for project: {}", projectId);
    }
}
