package com.qaassist.constants;

/**
 * Central constants used across the QA Assist framework.
 * No hard-coded values in test scripts — all values are referenced from here or config.
 */
public final class Constants {

    private Constants() {
        throw new UnsupportedOperationException("Constants class cannot be instantiated");
    }

    // ── Config File ──
    public static final String CONFIG_FILE_PATH = "src/main/resources/config.properties";

    // ── Timeouts (seconds) ──
    public static final int DEFAULT_IMPLICIT_WAIT = 10;
    public static final int DEFAULT_EXPLICIT_WAIT = 30;
    public static final int DEFAULT_PAGE_LOAD_TIMEOUT = 60;
    public static final int POLLING_INTERVAL_MS = 500;

    // ── Screenshot ──
    public static final String SCREENSHOT_FORMAT = "png";
    public static final String SCREENSHOT_DIR = "test-output/screenshots/";

    // ── Extent Report ──
    public static final String EXTENT_REPORT_DIR = "test-output/reports/";
    public static final String EXTENT_REPORT_NAME = "QA_Assist_Test_Report.html";
    public static final String REPORT_TITLE = "QA Assist - Automation Test Report";
    public static final String REPORT_NAME = "QA Assist Test Results";

    // ── Log ──
    public static final String LOG_DIR = "test-output/logs/";

    // ── Excel Columns ──
    public static final String COL_MODULE_FOLDER = "Module/Folder";
    public static final String COL_TEST_CASE_NAME = "Test Case Name";
    public static final String COL_PRE_CONDITIONS = "Pre-Conditions";
    public static final String COL_PRIORITY = "Priority";
    public static final String COL_TEST_CASE_TYPE = "Test Case Type";
    public static final String COL_TEST_STEPS = "Test Steps";
    public static final String COL_EXPECTED_RESULT = "Expected Result";

    // ── API Endpoints ──
    public static final String API_PROJECT_INSIGHTS = "/projects/{projectId}/insights";
    public static final String API_TEST_SUITES = "/projects/{projectId}/test-suites";
    public static final String API_TEST_CASES = "/projects/{projectId}/test-suites/{suiteId}/test-cases";
    public static final String API_ADD_TEST_CASE = "/projects/{projectId}/test-suites/{suiteId}/test-cases";
    public static final String API_REMOVE_TEST_CASE = "/projects/{projectId}/test-suites/{suiteId}/test-cases/{testCaseId}";
    public static final String API_RERUN = "/projects/{projectId}/test-suites/{suiteId}/rerun";
    public static final String API_DEFECTS = "/projects/{projectId}/defects";
    public static final String API_EXECUTION = "/projects/{projectId}/executions";

    // ── UI Element Identifiers (semantic) ──
    public static final String DASHBOARD_TITLE = "Dashboard";
    public static final String PROJECTS_SECTION = "Projects";
    public static final String TEST_SUITE_SECTION = "Test Suites";
    public static final String AI_ASSISTANT_LABEL = "Agent Assist";
    public static final String EXECUTION_ENGINE_LABEL = "Execution Engine";
    public static final String DEFECT_MANAGER_LABEL = "Defect Manager";
    public static final String TEST_CASE_MANAGER_LABEL = "Test Case Manager";

    // ── Prompts ──
    public static final String AI_FETCH_NOPCOMMERCE = "fetch Nopcommerce folder test cases";
    public static final String AI_FETCH_SAMSUNG = "Fetch Samsung tests";

    // ── Test Data ──
    public static final String DEFAULT_SUITE_PREFIX = "Apple Test Suite ";
    public static final String PROJECT_HU_QE_EDGE = "HU_QE_EDGE";
    public static final String PERSONA_WEB_AUTOMATION = "WebAutomation";

    // ── Metrics Labels ──
    public static final String METRIC_TOTAL_CASES = "Total Cases";
    public static final String METRIC_PASSED = "Passed";
    public static final String METRIC_FAILED = "Failed";
    public static final String METRIC_IN_PROGRESS = "In Progress";

    // ── qTest ──
    public static final String QTEST_API_TEST_RUNS = "/api/v3/projects/{projectId}/test-runs";
    public static final String QTEST_API_TEST_LOGS = "/api/v3/projects/{projectId}/test-runs/{testRunId}/test-logs";
}
