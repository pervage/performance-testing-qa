package com.qaassist.listeners;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.qaassist.base.DriverManager;
import com.qaassist.utils.ExtentReportManager;
import com.qaassist.utils.ScreenshotUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * TestNG Listener for test lifecycle events.
 * Handles ExtentReport updates and screenshot capture on failure/success.
 */
public class TestListener implements ITestListener {

    private static final Logger logger = LogManager.getLogger(TestListener.class);
    private static final ThreadLocal<ExtentTest> extentTestThread = new ThreadLocal<>();

    @Override
    public void onTestStart(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        String description = result.getMethod().getDescription();
        if (description == null || description.isEmpty()) {
            description = testName;
        }

        ExtentTest test = ExtentReportManager.createTest(testName, description);
        extentTestThread.set(test);

        // Add test groups/categories
        String[] groups = result.getMethod().getGroups();
        for (String group : groups) {
            test.assignCategory(group);
        }

        logger.info("▶ TEST STARTED: {}", testName);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        logger.info("✓ TEST PASSED: {} ({}ms)", testName, result.getEndMillis() - result.getStartMillis());

        ExtentTest test = extentTestThread.get();
        if (test != null) {
            // Capture success screenshot
            try {
                WebDriver driver = DriverManager.getDriver();
                String screenshotPath = ScreenshotUtils.takeScreenshot(driver, "PASS_" + testName);
                if (screenshotPath != null) {
                    test.pass("Test passed — screenshot captured",
                            com.aventstack.extentreports.MediaEntityBuilder
                                    .createScreenCaptureFromPath(screenshotPath).build());
                } else {
                    test.pass("Test passed");
                }
            } catch (Exception e) {
                test.pass("Test passed (screenshot unavailable)");
            }
        }

        // Push result to qTest if enabled
        QTestIntegration.pushTestResult(result, "PASS");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        Throwable throwable = result.getThrowable();
        logger.error("✗ TEST FAILED: {}", testName, throwable);

        ExtentTest test = extentTestThread.get();
        if (test != null) {
            test.log(Status.FAIL, "Test failed: " + throwable.getMessage());

            // Mandatory failure screenshot
            try {
                WebDriver driver = DriverManager.getDriver();
                String screenshotPath = ScreenshotUtils.takeScreenshot(driver, "FAIL_" + testName);
                if (screenshotPath != null) {
                    test.fail("Failure screenshot",
                            com.aventstack.extentreports.MediaEntityBuilder
                                    .createScreenCaptureFromPath(screenshotPath).build());
                }
            } catch (Exception e) {
                test.fail("Could not capture failure screenshot: " + e.getMessage());
            }

            test.fail(throwable);
        }

        // Push result to qTest if enabled
        QTestIntegration.pushTestResult(result, "FAIL");
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        logger.warn("⊘ TEST SKIPPED: {}", testName);

        ExtentTest test = extentTestThread.get();
        if (test != null) {
            test.skip("Test skipped");
            if (result.getThrowable() != null) {
                test.skip(result.getThrowable());
            }
        }

        QTestIntegration.pushTestResult(result, "SKIP");
    }

    @Override
    public void onStart(ITestContext context) {
        logger.info("═══════════ Suite Started: {} ═══════════", context.getName());
    }

    @Override
    public void onFinish(ITestContext context) {
        logger.info("═══════════ Suite Finished: {} ═══════════", context.getName());
        logger.info("Passed: {} | Failed: {} | Skipped: {}",
                context.getPassedTests().size(),
                context.getFailedTests().size(),
                context.getSkippedTests().size());
    }

    /**
     * Get the current ExtentTest for this thread.
     */
    public static ExtentTest getExtentTest() {
        return extentTestThread.get();
    }
}
