package com.qaassist.listeners;

import com.qaassist.config.ConfigReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/**
 * Retry analyzer for flaky tests. Retries failed tests up to configured count.
 */
public class RetryAnalyzer implements IRetryAnalyzer {

    private static final Logger logger = LogManager.getLogger(RetryAnalyzer.class);
    private int retryCount = 0;

    @Override
    public boolean retry(ITestResult result) {
        int maxRetry = ConfigReader.getRetryCount();
        if (retryCount < maxRetry) {
            retryCount++;
            logger.warn("Retrying test '{}' — attempt {}/{}", result.getName(), retryCount, maxRetry);
            return true;
        }
        return false;
    }
}
