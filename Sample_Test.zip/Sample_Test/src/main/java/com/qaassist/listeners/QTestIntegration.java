package com.qaassist.listeners;

import com.qaassist.config.ConfigReader;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestResult;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Integration with qTest to push test results automatically.
 * Results are populated in qTest when tests are executed.
 */
public class QTestIntegration {

    private static final Logger logger = LogManager.getLogger(QTestIntegration.class);

    private QTestIntegration() {
        throw new UnsupportedOperationException("QTestIntegration cannot be instantiated");
    }

    /**
     * Push test result to qTest.
     *
     * @param result ITestResult from TestNG
     * @param status PASS, FAIL, or SKIP
     */
    public static void pushTestResult(ITestResult result, String status) {
        if (!ConfigReader.isQTestEnabled()) {
            logger.debug("qTest integration disabled — skipping result push");
            return;
        }

        try {
            String qTestBaseUrl = ConfigReader.getQTestBaseUrl();
            String apiToken = ConfigReader.getQTestApiToken();
            String projectId = ConfigReader.getQTestProjectId();

            if (qTestBaseUrl == null || apiToken == null || projectId == null) {
                logger.warn("qTest configuration incomplete — skipping result push");
                return;
            }

            String testName = result.getMethod().getMethodName();
            long duration = result.getEndMillis() - result.getStartMillis();
            String executionTime = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            // Build test log payload
            Map<String, Object> testLog = new HashMap<>();
            testLog.put("name", testName);
            testLog.put("status", mapStatus(status));
            testLog.put("exe_start_date", executionTime);
            testLog.put("exe_end_date", executionTime);
            testLog.put("note", buildNote(result, status, duration));

            Map<String, Object> statusMap = new HashMap<>();
            statusMap.put("name", mapStatus(status));
            testLog.put("status", statusMap);

            // Create test run if not exists, then add log
            String testRunEndpoint = qTestBaseUrl + "/api/v3/projects/" + projectId + "/auto-test-logs";

            Map<String, Object> payload = new HashMap<>();
            payload.put("test_logs", new Object[]{testLog});

            Map<String, Object> testCycle = new HashMap<>();
            testCycle.put("name", "Automation Run - " + LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            payload.put("test_cycle", testCycle);

            Response response = RestAssured.given()
                    .baseUri(qTestBaseUrl)
                    .header("Authorization", "Bearer " + apiToken)
                    .contentType(ContentType.JSON)
                    .body(payload)
                    .post("/api/v3/projects/" + projectId + "/auto-test-logs");

            if (response.getStatusCode() == 200 || response.getStatusCode() == 201) {
                logger.info("Successfully pushed result to qTest for: {} [{}]", testName, status);
            } else {
                logger.warn("Failed to push result to qTest. Status: {} Body: {}",
                        response.getStatusCode(), response.getBody().asString());
            }

        } catch (Exception e) {
            logger.error("Error pushing result to qTest", e);
        }
    }

    /**
     * Map internal status to qTest status name.
     */
    private static String mapStatus(String status) {
        return switch (status.toUpperCase()) {
            case "PASS" -> "Passed";
            case "FAIL" -> "Failed";
            case "SKIP" -> "Skipped";
            default -> "Unexecuted";
        };
    }

    /**
     * Build a note/description for the test log.
     */
    private static String buildNote(ITestResult result, String status, long durationMs) {
        StringBuilder note = new StringBuilder();
        note.append("Test: ").append(result.getMethod().getMethodName()).append("\n");
        note.append("Class: ").append(result.getTestClass().getName()).append("\n");
        note.append("Status: ").append(status).append("\n");
        note.append("Duration: ").append(durationMs).append("ms\n");

        if (result.getThrowable() != null) {
            note.append("Error: ").append(result.getThrowable().getMessage()).append("\n");
        }

        String description = result.getMethod().getDescription();
        if (description != null && !description.isEmpty()) {
            note.append("Description: ").append(description);
        }

        return note.toString();
    }
}
