package com.qaassist.exceptions;

/**
 * Custom exception for the QA Assist framework.
 * Wraps all framework-level errors for consistent exception handling.
 */
public class FrameworkException extends RuntimeException {

    public FrameworkException(String message) {
        super(message);
    }

    public FrameworkException(String message, Throwable cause) {
        super(message, cause);
    }

    public FrameworkException(Throwable cause) {
        super(cause);
    }
}
