package com.qaassist.pages;

import com.qaassist.constants.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Page object for Test Case Manager — upload Excel, browse folders, view/edit test cases.
 */
public class TestCaseManagerPage extends BasePage {

    // ── Locators ──
    private static final By BTN_UPLOAD_EXCEL = By.cssSelector(
            "button[data-testid='upload-excel'], .upload-btn, input[type='file']");
    private static final By INPUT_FILE = By.cssSelector("input[type='file']");
    private static final By LBL_UPLOAD_SUCCESS = By.xpath(
            "//*[contains(text(),'uploaded successfully') or contains(text(),'Upload complete')]");
    private static final By LIST_FOLDERS = By.cssSelector(
            ".folder-item, .tree-node, [data-testid='folder-item']");
    private static final By LIST_TEST_CASES = By.cssSelector(
            ".test-case-item, .testcase-row, [data-testid='test-case-item']");
    private static final By LBL_TC_NAME = By.cssSelector(
            ".test-case-name, [data-testid='tc-name'], .detail-name");
    private static final By LBL_TC_PRECONDITIONS = By.cssSelector(
            ".test-case-preconditions, [data-testid='tc-preconditions'], .detail-preconditions");
    private static final By LBL_TC_PRIORITY = By.cssSelector(
            ".test-case-priority, [data-testid='tc-priority'], .detail-priority");
    private static final By LBL_TC_TYPE = By.cssSelector(
            ".test-case-type, [data-testid='tc-type'], .detail-type");
    private static final By LBL_TC_ID = By.cssSelector(
            ".test-case-id, [data-testid='tc-id'], .detail-id");
    private static final By TAB_TEST_STEPS = By.xpath(
            "//*[contains(text(),'Test Steps') or @data-testid='tab-test-steps']");
    private static final By BTN_EDIT_STEPS = By.xpath(
            "//*[contains(text(),'Edit Steps') or @data-testid='btn-edit-steps']");
    private static final By BTN_DONE_EDITING = By.xpath(
            "//*[contains(text(),'Done') or @data-testid='btn-done-editing']");
    private static final By BTN_SAVE_CHANGES = By.xpath(
            "//*[contains(text(),'Save') or @data-testid='btn-save-changes']");
    private static final By INPUT_TEST_STEP = By.cssSelector(
            ".test-step-input, [data-testid='test-step-input'], textarea.step-description");
    private static final By BTN_OPEN_TEST_MANAGER = By.xpath(
            "//*[contains(text(),'Open Test Manager') or @data-testid='btn-open-test-manager']");
    private static final By DROPDOWN_PROJECT = By.cssSelector(
            "select[data-testid='project-select'], .project-dropdown");
    private static final By BTN_THREE_DOTS_MENU = By.cssSelector(
            ".three-dots-menu, .kebab-menu, [data-testid='folder-menu'], .more-options");
    private static final By BTN_DELETE_FOLDER = By.xpath(
            "//*[contains(text(),'Delete Folder') or contains(text(),'Delete')]");
    private static final By BTN_CONFIRM_DELETE = By.xpath(
            "//*[contains(text(),'Confirm') or contains(text(),'Yes') or @data-testid='btn-confirm-delete']");
    private static final By MODAL_DELETE_CONFIRM = By.cssSelector(
            ".modal-confirm, .delete-confirmation, [data-testid='delete-modal']");

    public TestCaseManagerPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Upload an Excel file into Test Case Manager.
     */
    public TestCaseManagerPage uploadExcelFile(String filePath) {
        WebElement fileInput = driver.findElement(INPUT_FILE);
        fileInput.sendKeys(filePath);
        logger.info("Uploading Excel file: {}", filePath);
        // Wait for upload success
        isElementDisplayed(LBL_UPLOAD_SUCCESS, 30);
        capturePageScreenshot("Excel_Upload_Complete");
        return this;
    }

    /**
     * Verify a folder name appears in the folder tree/list.
     */
    public boolean isFolderVisible(String folderName) {
        By folderLocator = By.xpath(
                "//*[contains(@class,'folder') or contains(@class,'tree')]" +
                        "//*[contains(text(),'" + folderName + "')]");
        boolean visible = isElementDisplayed(folderLocator, 10);
        logger.info("Folder '{}' visible: {}", folderName, visible);
        return visible;
    }

    /**
     * Click on a folder to expand/open it.
     */
    public TestCaseManagerPage clickFolder(String folderName) {
        By folderLocator = By.xpath(
                "//*[contains(@class,'folder') or contains(@class,'tree')]" +
                        "//*[contains(text(),'" + folderName + "')]");
        click(folderLocator);
        waitForPageLoad();
        logger.info("Clicked folder: {}", folderName);
        capturePageScreenshot("Folder_Expanded_" + folderName);
        return this;
    }

    /**
     * Open the first test case under the currently expanded folder.
     */
    public TestCaseManagerPage openFirstTestCase() {
        List<WebElement> testCases = driver.findElements(LIST_TEST_CASES);
        if (!testCases.isEmpty()) {
            testCases.get(0).click();
            waitForPageLoad();
            logger.info("Opened first test case");
            capturePageScreenshot("First_TestCase_Opened");
        } else {
            logger.warn("No test cases found under the folder");
        }
        return this;
    }

    /**
     * Get the displayed test case name.
     */
    public String getTestCaseName() {
        return getText(LBL_TC_NAME);
    }

    /**
     * Get the displayed pre-conditions.
     */
    public String getPreConditions() {
        return getText(LBL_TC_PRECONDITIONS);
    }

    /**
     * Get the displayed priority.
     */
    public String getPriority() {
        return getText(LBL_TC_PRIORITY);
    }

    /**
     * Get the displayed test case type.
     */
    public String getTestCaseType() {
        return getText(LBL_TC_TYPE);
    }

    /**
     * Get the displayed test case ID.
     */
    public String getTestCaseId() {
        return getText(LBL_TC_ID);
    }

    /**
     * Click on Test Steps tab.
     */
    public TestCaseManagerPage clickTestStepsTab() {
        click(TAB_TEST_STEPS);
        waitForPageLoad();
        logger.info("Clicked Test Steps tab");
        return this;
    }

    /**
     * Click Edit Steps button.
     */
    public TestCaseManagerPage clickEditSteps() {
        click(BTN_EDIT_STEPS);
        logger.info("Clicked Edit Steps");
        return this;
    }

    /**
     * Edit the first test step.
     */
    public TestCaseManagerPage editFirstTestStep(String newStepText) {
        List<WebElement> stepInputs = driver.findElements(INPUT_TEST_STEP);
        if (!stepInputs.isEmpty()) {
            stepInputs.get(0).clear();
            stepInputs.get(0).sendKeys(newStepText);
            logger.info("Edited first test step to: {}", newStepText);
        }
        return this;
    }

    /**
     * Click Done Editing button.
     */
    public TestCaseManagerPage clickDoneEditing() {
        click(BTN_DONE_EDITING);
        logger.info("Clicked Done Editing");
        return this;
    }

    /**
     * Click Save Changes button.
     */
    public TestCaseManagerPage clickSaveChanges() {
        click(BTN_SAVE_CHANGES);
        waitForPageLoad();
        logger.info("Clicked Save Changes");
        capturePageScreenshot("TestCase_Saved");
        return this;
    }

    /**
     * Select project within Test Case Manager.
     */
    public TestCaseManagerPage selectProject(String projectName) {
        try {
            selectByVisibleText(DROPDOWN_PROJECT, projectName);
        } catch (Exception e) {
            click(DROPDOWN_PROJECT);
            click(By.xpath("//*[contains(text(),'" + projectName + "')]"));
        }
        waitForPageLoad();
        logger.info("Selected project: {}", projectName);
        return this;
    }

    /**
     * Click Open Test Manager button.
     */
    public TestCaseManagerPage clickOpenTestManager() {
        click(BTN_OPEN_TEST_MANAGER);
        waitForPageLoad();
        logger.info("Clicked Open Test Manager");
        capturePageScreenshot("TestManager_Opened");
        return this;
    }

    /**
     * Click three-dots/kebab menu for a specific folder.
     */
    public TestCaseManagerPage clickFolderMenu(String folderName) {
        // Hover on folder to reveal menu
        By folderLocator = By.xpath(
                "//*[contains(@class,'folder') or contains(@class,'tree')]" +
                        "//*[contains(text(),'" + folderName + "')]");
        hoverOver(folderLocator);
        // Click the three dots menu near this folder
        By menuLocator = By.xpath(
                "//*[contains(text(),'" + folderName + "')]/ancestor::*[contains(@class,'folder')]" +
                        "//*[contains(@class,'menu') or contains(@class,'dots') or contains(@class,'kebab')]");
        try {
            click(menuLocator);
        } catch (Exception e) {
            click(BTN_THREE_DOTS_MENU);
        }
        logger.info("Opened menu for folder: {}", folderName);
        return this;
    }

    /**
     * Click Delete Folder option from menu.
     */
    public TestCaseManagerPage clickDeleteFolder() {
        click(BTN_DELETE_FOLDER);
        logger.info("Clicked Delete Folder");
        return this;
    }

    /**
     * Confirm folder deletion in the popup.
     */
    public TestCaseManagerPage confirmDelete() {
        if (isElementDisplayed(MODAL_DELETE_CONFIRM, 5)) {
            click(BTN_CONFIRM_DELETE);
            waitForPageLoad();
            logger.info("Confirmed folder deletion");
            capturePageScreenshot("Folder_Deleted");
        }
        return this;
    }

    /**
     * Verify folder is no longer visible.
     */
    public boolean isFolderAbsent(String folderName) {
        By folderLocator = By.xpath(
                "//*[contains(@class,'folder') or contains(@class,'tree')]" +
                        "//*[contains(text(),'" + folderName + "')]");
        boolean absent = !isElementDisplayed(folderLocator, 5);
        logger.info("Folder '{}' absent: {}", folderName, absent);
        return absent;
    }

    /**
     * Check if upload was successful.
     */
    public boolean isUploadSuccessful() {
        return isElementDisplayed(LBL_UPLOAD_SUCCESS, 15);
    }

    /**
     * Get all visible test case names.
     */
    public List<String> getAllTestCaseNames() {
        List<WebElement> elements = driver.findElements(LIST_TEST_CASES);
        return elements.stream().map(WebElement::getText).toList();
    }
}
