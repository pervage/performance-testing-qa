package com.qaassist.pages;

import com.qaassist.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Page object for the AI Assistant / Agent Assist chat panel.
 */
public class AIAssistantPage extends BasePage {

    // ── Locators ──
    private static final By PANEL_CHAT = By.cssSelector(
            ".chat-panel, .ai-assistant-panel, [data-testid='ai-panel']");
    private static final By INPUT_CHAT = By.cssSelector(
            "input[data-testid='chat-input'], textarea[data-testid='chat-input'], .chat-input, .prompt-input");
    private static final By BTN_SEND = By.cssSelector(
            "button[data-testid='send-btn'], .send-button, [aria-label='Send']");
    private static final By BTN_CLOSE_PANEL = By.cssSelector(
            "button[data-testid='close-panel'], .close-btn, [aria-label='Close']");
    private static final By SPINNER_PROCESSING = By.cssSelector(
            ".spinner, .processing, .loading, [data-testid='ai-loading']");
    private static final By LIST_POPULATED_TEST_CASES = By.cssSelector(
            ".test-case-item, .populated-case, [data-testid='ai-test-case']");
    private static final By LBL_ERROR_MESSAGE = By.cssSelector(
            ".error-message, .alert-danger, [data-testid='error-msg'], .error");
    private static final By LBL_RESPONSE = By.cssSelector(
            ".ai-response, .chat-response, [data-testid='ai-response']");

    public AIAssistantPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Check if chat panel is open.
     */
    public boolean isChatPanelOpen() {
        boolean open = isElementDisplayed(PANEL_CHAT, 10);
        logger.info("AI Chat panel open: {}", open);
        capturePageScreenshot("AI_Panel_State");
        return open;
    }

    /**
     * Send a query/prompt to the AI Assistant.
     */
    public AIAssistantPage sendQuery(String query) {
        type(INPUT_CHAT, query);
        click(BTN_SEND);
        logger.info("Sent AI query: {}", query);
        capturePageScreenshot("AI_Query_Sent");
        return this;
    }

    /**
     * Wait for AI to finish processing the query.
     */
    public AIAssistantPage waitForAIResponse() {
        // Wait for processing spinner to disappear
        waitForElementToDisappear(SPINNER_PROCESSING, 120);
        waitForPageLoad();
        logger.info("AI response received");
        capturePageScreenshot("AI_Response_Received");
        return this;
    }

    /**
     * Wait for test cases to populate after AI response.
     */
    public AIAssistantPage waitForTestCasesToPopulate() {
        WaitUtils.waitForElementVisible(driver, LIST_POPULATED_TEST_CASES, 60);
        logger.info("Test cases populated from AI");
        capturePageScreenshot("AI_TestCases_Populated");
        return this;
    }

    /**
     * Get the number of populated test cases.
     */
    public int getPopulatedTestCaseCount() {
        List<WebElement> cases = driver.findElements(LIST_POPULATED_TEST_CASES);
        return cases.size();
    }

    /**
     * Close the AI Assistant panel.
     */
    public void closePanel() {
        click(BTN_CLOSE_PANEL);
        logger.info("AI panel closed");
        capturePageScreenshot("AI_Panel_Closed");
    }

    /**
     * Check if an error message is displayed.
     */
    public boolean isErrorMessageDisplayed() {
        boolean displayed = isElementDisplayed(LBL_ERROR_MESSAGE, 10);
        logger.info("Error message displayed: {}", displayed);
        return displayed;
    }

    /**
     * Get the error message text.
     */
    public String getErrorMessage() {
        return getText(LBL_ERROR_MESSAGE);
    }

    /**
     * Get the AI response text.
     */
    public String getResponseText() {
        return getText(LBL_RESPONSE);
    }
}
