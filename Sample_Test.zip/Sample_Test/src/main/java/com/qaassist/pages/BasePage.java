package com.qaassist.pages;

import com.qaassist.utils.ScreenshotUtils;
import com.qaassist.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Base page providing common page interactions for all POM classes.
 */
public abstract class BasePage {

    protected final WebDriver driver;
    protected final Logger logger;

    protected BasePage(WebDriver driver) {
        this.driver = driver;
        this.logger = LogManager.getLogger(this.getClass());
        PageFactory.initElements(driver, this);
    }

    // ── Click Actions ──

    protected void click(By locator) {
        WebElement element = WaitUtils.waitForElementClickable(driver, locator);
        element.click();
        logger.debug("Clicked element: {}", locator);
    }

    protected void click(WebElement element) {
        WaitUtils.waitForElementClickable(driver, toBy(element));
        element.click();
    }

    protected void jsClick(By locator) {
        WebElement element = WaitUtils.waitForElementPresent(driver, locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        logger.debug("JS clicked element: {}", locator);
    }

    // ── Input Actions ──

    protected void type(By locator, String text) {
        WebElement element = WaitUtils.waitForElementVisible(driver, locator);
        element.clear();
        element.sendKeys(text);
        logger.debug("Typed '{}' into: {}", text, locator);
    }

    protected void clearAndType(By locator, String text) {
        WebElement element = WaitUtils.waitForElementVisible(driver, locator);
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(Keys.DELETE);
        element.sendKeys(text);
    }

    // ── Read Actions ──

    protected String getText(By locator) {
        WebElement element = WaitUtils.waitForElementVisible(driver, locator);
        return element.getText().trim();
    }

    protected String getAttribute(By locator, String attribute) {
        WebElement element = WaitUtils.waitForElementPresent(driver, locator);
        return element.getAttribute(attribute);
    }

    // ── Verification ──

    protected boolean isElementDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (NoSuchElementException | StaleElementReferenceException e) {
            return false;
        }
    }

    protected boolean isElementDisplayed(By locator, int timeoutSeconds) {
        try {
            WaitUtils.waitForElementVisible(driver, locator, timeoutSeconds);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    protected boolean isElementEnabled(By locator) {
        try {
            return driver.findElement(locator).isEnabled();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    // ── Select Dropdown ──

    protected void selectByVisibleText(By locator, String text) {
        WebElement element = WaitUtils.waitForElementVisible(driver, locator);
        Select select = new Select(element);
        select.selectByVisibleText(text);
        logger.debug("Selected '{}' from dropdown: {}", text, locator);
    }

    protected void selectByValue(By locator, String value) {
        WebElement element = WaitUtils.waitForElementVisible(driver, locator);
        Select select = new Select(element);
        select.selectByValue(value);
    }

    // ── Scrolling ──

    protected void scrollToElement(By locator) {
        WebElement element = WaitUtils.waitForElementPresent(driver, locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior:'smooth',block:'center'});", element);
    }

    protected void scrollToTop() {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 0);");
    }

    protected void scrollToBottom() {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
    }

    // ── Hover ──

    protected void hoverOver(By locator) {
        WebElement element = WaitUtils.waitForElementVisible(driver, locator);
        new Actions(driver).moveToElement(element).perform();
    }

    // ── File Upload ──

    protected void uploadFile(By locator, String filePath) {
        WebElement element = WaitUtils.waitForElementPresent(driver, locator);
        element.sendKeys(filePath);
        logger.info("Uploaded file: {}", filePath);
    }

    // ── Wait Helpers ──

    protected void waitForPageLoad() {
        WaitUtils.waitForPageLoad(driver);
    }

    protected void waitForElementToDisappear(By locator, int timeoutSeconds) {
        WaitUtils.waitForElementInvisible(driver, locator, timeoutSeconds);
    }

    // ── Screenshot ──

    protected String capturePageScreenshot(String stepName) {
        return ScreenshotUtils.takeScreenshot(driver, stepName);
    }

    // ── URL ──

    protected String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    protected String getPageTitle() {
        return driver.getTitle();
    }

    // ── Internal Helpers ──

    private By toBy(WebElement element) {
        // Fallback — use xpath
        String description = element.toString();
        if (description.contains("->")) {
            String[] parts = description.split("->");
            String locatorPart = parts[parts.length - 1].trim().replace("]", "");
            String[] typAndVal = locatorPart.split(":");
            if (typAndVal.length == 2) {
                String type = typAndVal[0].trim();
                String value = typAndVal[1].trim();
                return switch (type) {
                    case "id" -> By.id(value);
                    case "name" -> By.name(value);
                    case "className", "class name" -> By.className(value);
                    case "cssSelector", "css selector" -> By.cssSelector(value);
                    case "xpath" -> By.xpath(value);
                    default -> By.xpath("//*");
                };
            }
        }
        return By.xpath("//*");
    }
}
