package com.qaassist.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Page object for the Defect Manager — create defects, handle duplicates.
 */
public class DefectManagerPage extends BasePage {

    // ── Locators ──
    private static final By LBL_DEFECT_MANAGER_TITLE = By.xpath(
            "//*[contains(text(),'Defect Manager') or contains(@class,'defect-manager')]");
    private static final By BTN_CREATE_DEFECT = By.xpath(
            "//*[contains(text(),'Create') and contains(text(),'Defect') or @data-testid='btn-create-defect']");
    private static final By LBL_DUPLICATE_ANALYSIS = By.xpath(
            "//*[contains(text(),'Duplicate') and contains(text(),'Analysis')]");
    private static final By BTN_USE_SELECTED_DEFECT = By.xpath(
            "//*[contains(text(),'Use Selected Defect') or @data-testid='btn-use-selected']");
    private static final By BTN_CREATE_NEW_DEFECT = By.xpath(
            "//*[contains(text(),'Create New Defect') or @data-testid='btn-create-new']");
    private static final By INPUT_DEFECT_TITLE = By.cssSelector(
            "input[data-testid='defect-title'], input[name='defectTitle'], .defect-title-input");
    private static final By INPUT_DEFECT_DESCRIPTION = By.cssSelector(
            "textarea[data-testid='defect-description'], textarea[name='description'], .defect-desc-input");
    private static final By BTN_SUBMIT_DEFECT = By.xpath(
            "//*[contains(text(),'Submit') or @data-testid='btn-submit-defect']");
    private static final By LBL_DEFECT_CREATED = By.xpath(
            "//*[contains(text(),'created') or contains(text(),'successfully')]");

    public DefectManagerPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Verify Defect Manager page is loaded.
     */
    public boolean isDefectManagerLoaded() {
        waitForPageLoad();
        boolean loaded = isElementDisplayed(LBL_DEFECT_MANAGER_TITLE, 15);
        logger.info("Defect Manager loaded: {}", loaded);
        capturePageScreenshot("DefectManager_Loaded");
        return loaded;
    }

    /**
     * Handle duplicate defect analysis — use selected or create new.
     */
    public DefectManagerPage handleDuplicateDefectAnalysis() {
        if (isElementDisplayed(LBL_DUPLICATE_ANALYSIS, 10)) {
            logger.info("Duplicate Defect Analysis detected");
            capturePageScreenshot("Duplicate_Defect_Analysis");

            if (isElementEnabled(BTN_USE_SELECTED_DEFECT)) {
                click(BTN_USE_SELECTED_DEFECT);
                logger.info("Selected: Use Selected Defect");
            } else {
                click(BTN_CREATE_NEW_DEFECT);
                logger.info("Selected: Create New Defect");
            }
            waitForPageLoad();
            capturePageScreenshot("Duplicate_Defect_Handled");
        } else {
            logger.info("No duplicate defect analysis shown — proceeding");
        }
        return this;
    }

    /**
     * Create a new defect with title and description.
     */
    public DefectManagerPage createDefect(String title, String description) {
        if (isElementDisplayed(INPUT_DEFECT_TITLE, 5)) {
            type(INPUT_DEFECT_TITLE, title);
            type(INPUT_DEFECT_DESCRIPTION, description);
            click(BTN_SUBMIT_DEFECT);
            waitForPageLoad();
            logger.info("Created defect: {}", title);
            capturePageScreenshot("Defect_Created");
        }
        return this;
    }

    /**
     * Click Create Defect button.
     */
    public DefectManagerPage clickCreateDefect() {
        click(BTN_CREATE_DEFECT);
        waitForPageLoad();
        logger.info("Clicked Create Defect");
        return this;
    }

    /**
     * Verify defect creation success.
     */
    public boolean isDefectCreatedSuccessfully() {
        return isElementDisplayed(LBL_DEFECT_CREATED, 10);
    }

    /**
     * Verify the Defect Manager URL/page is displayed.
     */
    public boolean isOnDefectManagerPage() {
        String currentUrl = getCurrentUrl();
        boolean onPage = currentUrl.contains("defect") || isElementDisplayed(LBL_DEFECT_MANAGER_TITLE, 5);
        logger.info("On Defect Manager page: {}", onPage);
        return onPage;
    }
}
