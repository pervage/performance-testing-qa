package com.qaassist.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Page object for the Login/SSO page.
 * Supports Chrome profile-based Microsoft SSO authentication.
 */
public class LoginPage extends BasePage {

    // ── Locators ──
    private static final By INPUT_EMAIL = By.cssSelector("input[type='email']");
    private static final By INPUT_PASSWORD = By.cssSelector("input[type='password']");
    private static final By BTN_NEXT = By.cssSelector("input[type='submit']");
    private static final By BTN_SIGN_IN = By.cssSelector("input[type='submit'][value='Sign in']");
    private static final By BTN_YES_STAY_SIGNED_IN = By.cssSelector("input[type='submit'][value='Yes']");
    private static final By LBL_DISPLAY_NAME = By.id("displayName");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Navigate to the application URL.
     */
    public LoginPage navigateTo(String url) {
        driver.get(url);
        waitForPageLoad();
        logger.info("Navigated to: {}", url);
        return this;
    }

    /**
     * Enter email for SSO.
     */
    public LoginPage enterEmail(String email) {
        type(INPUT_EMAIL, email);
        return this;
    }

    /**
     * Click Next button.
     */
    public LoginPage clickNext() {
        click(BTN_NEXT);
        return this;
    }

    /**
     * Enter password.
     */
    public LoginPage enterPassword(String password) {
        type(INPUT_PASSWORD, password);
        return this;
    }

    /**
     * Click Sign In button.
     */
    public LoginPage clickSignIn() {
        click(BTN_SIGN_IN);
        return this;
    }

    /**
     * Click 'Yes' on Stay Signed In prompt.
     */
    public LoginPage clickStaySignedIn() {
        if (isElementDisplayed(BTN_YES_STAY_SIGNED_IN, 5)) {
            click(BTN_YES_STAY_SIGNED_IN);
        }
        return this;
    }

    /**
     * Full SSO login flow using Chrome profile — just navigate, SSO handles auth.
     */
    public DashboardPage loginWithSSOProfile(String appUrl) {
        navigateTo(appUrl);
        waitForPageLoad();
        // With Chrome profile, SSO authentication is automatic
        logger.info("SSO login completed via Chrome profile");
        capturePageScreenshot("SSO_Login_Success");
        return new DashboardPage(driver);
    }

    /**
     * Full manual SSO login.
     */
    public DashboardPage loginWithCredentials(String appUrl, String email, String password) {
        navigateTo(appUrl);
        if (isElementDisplayed(INPUT_EMAIL, 10)) {
            enterEmail(email);
            clickNext();
            enterPassword(password);
            clickSignIn();
            clickStaySignedIn();
        }
        waitForPageLoad();
        capturePageScreenshot("Login_Success");
        return new DashboardPage(driver);
    }

    /**
     * Check if login page is displayed.
     */
    public boolean isLoginPageDisplayed() {
        return isElementDisplayed(INPUT_EMAIL, 10);
    }
}
