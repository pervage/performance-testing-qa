package com.qaassist.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Page object for Execution Engine — view execution results, metrics.
 */
public class ExecutionEnginePage extends BasePage {

    // ── Locators ──
    private static final By LBL_SUITE_NAME = By.cssSelector(
            ".suite-name, [data-testid='execution-suite-name'], .execution-title");
    private static final By LBL_METRIC_TOTAL = By.xpath(
            "//*[contains(text(),'Total Cases') or contains(text(),'Total')]");
    private static final By LBL_METRIC_PASSED = By.xpath(
            "//*[contains(text(),'Passed')]");
    private static final By LBL_METRIC_FAILED = By.xpath(
            "//*[contains(text(),'Failed')]");
    private static final By LBL_METRIC_IN_PROGRESS = By.xpath(
            "//*[contains(text(),'In Progress')]");
    private static final By LIST_EXECUTED_CASES = By.cssSelector(
            ".executed-case, .execution-row, [data-testid='executed-case']");
    private static final By CHECKBOX_SELECT_ALL = By.cssSelector(
            "input[data-testid='select-all-executed'], .select-all, [aria-label='Select All']");
    private static final By BTN_ADD_TO_DEFECT = By.xpath(
            "//*[contains(text(),'Add to Defect') or contains(text(),'Defect Tracker') or @data-testid='btn-add-defect']");
    private static final By SPINNER_EXECUTION = By.cssSelector(
            ".execution-spinner, .running, [data-testid='execution-loading']");

    public ExecutionEnginePage(WebDriver driver) {
        super(driver);
    }

    /**
     * Verify suite name appears in Execution Engine.
     */
    public boolean isSuiteNameDisplayed(String suiteName) {
        By suiteLocator = By.xpath("//*[contains(text(),'" + suiteName + "')]");
        boolean displayed = isElementDisplayed(suiteLocator, 15);
        logger.info("Suite '{}' in Execution Engine: {}", suiteName, displayed);
        capturePageScreenshot("ExecutionEngine_SuiteVerified");
        return displayed;
    }

    /**
     * Verify all metrics labels exist.
     */
    public boolean areMetricsLabelsVisible() {
        boolean totalVisible = isElementDisplayed(LBL_METRIC_TOTAL);
        boolean passedVisible = isElementDisplayed(LBL_METRIC_PASSED);
        boolean failedVisible = isElementDisplayed(LBL_METRIC_FAILED);
        boolean inProgressVisible = isElementDisplayed(LBL_METRIC_IN_PROGRESS);

        boolean allVisible = totalVisible && passedVisible && failedVisible && inProgressVisible;
        logger.info("Metrics labels visible — Total: {}, Passed: {}, Failed: {}, InProgress: {}",
                totalVisible, passedVisible, failedVisible, inProgressVisible);
        capturePageScreenshot("ExecutionEngine_Metrics");
        return allVisible;
    }

    /**
     * Get the suite name displayed.
     */
    public String getSuiteName() {
        return getText(LBL_SUITE_NAME);
    }

    /**
     * Select all executed test cases.
     */
    public ExecutionEnginePage selectAllExecutedCases() {
        click(CHECKBOX_SELECT_ALL);
        logger.info("Selected all executed test cases");
        capturePageScreenshot("All_Executed_Selected");
        return this;
    }

    /**
     * Click Add to Defect Tracker / Defect Manager.
     */
    public DefectManagerPage clickAddToDefect() {
        click(BTN_ADD_TO_DEFECT);
        waitForPageLoad();
        logger.info("Clicked Add to Defect Tracker");
        capturePageScreenshot("Navigate_DefectManager");
        return new DefectManagerPage(driver);
    }

    /**
     * Wait for execution to complete.
     */
    public ExecutionEnginePage waitForExecutionComplete() {
        waitForElementToDisappear(SPINNER_EXECUTION, 180);
        waitForPageLoad();
        logger.info("Execution completed");
        capturePageScreenshot("Execution_Complete");
        return this;
    }

    /**
     * Get count of executed cases.
     */
    public int getExecutedCaseCount() {
        List<WebElement> cases = driver.findElements(LIST_EXECUTED_CASES);
        return cases.size();
    }
}
