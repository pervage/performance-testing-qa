package com.qaassist.pages;

import com.qaassist.constants.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Page object for the Dashboard / Landing page after login.
 */
public class DashboardPage extends BasePage {

    // ── Locators ──
    private static final By LBL_DASHBOARD_TITLE = By.xpath(
            "//*[contains(text(),'Dashboard') or contains(@class,'dashboard')]");
    private static final By SECTION_PROJECTS = By.xpath(
            "//*[contains(text(),'Projects') or contains(@class,'project')]");
    private static final By DROPDOWN_PROJECT = By.cssSelector(
            "select[data-testid='project-select'], .project-dropdown, [aria-label='Select Project']");
    private static final By OPTION_PROJECT_LIST = By.cssSelector(
            ".project-dropdown option, .project-list-item, [data-testid='project-option']");
    private static final By LBL_SELECTED_PROJECT = By.cssSelector(
            ".selected-project, [data-testid='selected-project']");
    private static final By NAV_TEST_SUITE = By.xpath(
            "//*[contains(text(),'Test Suite') or @data-testid='nav-test-suite']");
    private static final By NAV_TEST_CASE_MANAGER = By.xpath(
            "//*[contains(text(),'Test Case Manager') or @data-testid='nav-test-case-manager']");
    private static final By NAV_AI_ASSISTANT = By.xpath(
            "//*[contains(text(),'Agent Assist') or contains(text(),'AI Assistant') or @data-testid='nav-ai-assistant']");
    private static final By NAV_EXECUTION_ENGINE = By.xpath(
            "//*[contains(text(),'Execution Engine') or @data-testid='nav-execution-engine']");
    private static final By NAV_DEFECT_MANAGER = By.xpath(
            "//*[contains(text(),'Defect Manager') or @data-testid='nav-defect-manager']");
    private static final By DROPDOWN_PERSONA = By.cssSelector(
            "select[data-testid='persona-select'], .persona-dropdown, [aria-label='Select Persona']");

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Verify Dashboard page is displayed.
     */
    public boolean isDashboardDisplayed() {
        waitForPageLoad();
        boolean displayed = isElementDisplayed(LBL_DASHBOARD_TITLE, 15);
        logger.info("Dashboard displayed: {}", displayed);
        capturePageScreenshot("Dashboard_Loaded");
        return displayed;
    }

    /**
     * Verify Projects section is visible.
     */
    public boolean isProjectsSectionVisible() {
        boolean visible = isElementDisplayed(SECTION_PROJECTS, 10);
        logger.info("Projects section visible: {}", visible);
        return visible;
    }

    /**
     * Select a project from the dropdown.
     */
    public DashboardPage selectProject(String projectName) {
        try {
            // Try standard select dropdown
            selectByVisibleText(DROPDOWN_PROJECT, projectName);
        } catch (Exception e) {
            // Try clicking dropdown and selecting option
            click(DROPDOWN_PROJECT);
            By projectOption = By.xpath(
                    "//*[contains(text(),'" + projectName + "')]");
            click(projectOption);
        }
        waitForPageLoad();
        logger.info("Selected project: {}", projectName);
        capturePageScreenshot("Project_Selected_" + projectName);
        return this;
    }

    /**
     * Get the currently selected project name.
     */
    public String getSelectedProjectName() {
        try {
            return getText(LBL_SELECTED_PROJECT);
        } catch (Exception e) {
            return getAttribute(DROPDOWN_PROJECT, "value");
        }
    }

    /**
     * Navigate to Test Suite section.
     */
    public TestSuitePage navigateToTestSuite() {
        click(NAV_TEST_SUITE);
        waitForPageLoad();
        logger.info("Navigated to Test Suite");
        capturePageScreenshot("Navigate_TestSuite");
        return new TestSuitePage(driver);
    }

    /**
     * Navigate to Test Case Manager.
     */
    public TestCaseManagerPage navigateToTestCaseManager() {
        click(NAV_TEST_CASE_MANAGER);
        waitForPageLoad();
        logger.info("Navigated to Test Case Manager");
        capturePageScreenshot("Navigate_TestCaseManager");
        return new TestCaseManagerPage(driver);
    }

    /**
     * Navigate to AI Assistant / Agent Assist.
     */
    public AIAssistantPage navigateToAIAssistant() {
        click(NAV_AI_ASSISTANT);
        waitForPageLoad();
        logger.info("Navigated to AI Assistant");
        capturePageScreenshot("Navigate_AIAssistant");
        return new AIAssistantPage(driver);
    }

    /**
     * Navigate to Execution Engine.
     */
    public ExecutionEnginePage navigateToExecutionEngine() {
        click(NAV_EXECUTION_ENGINE);
        waitForPageLoad();
        logger.info("Navigated to Execution Engine");
        capturePageScreenshot("Navigate_ExecutionEngine");
        return new ExecutionEnginePage(driver);
    }

    /**
     * Navigate to Defect Manager.
     */
    public DefectManagerPage navigateToDefectManager() {
        click(NAV_DEFECT_MANAGER);
        waitForPageLoad();
        logger.info("Navigated to Defect Manager");
        capturePageScreenshot("Navigate_DefectManager");
        return new DefectManagerPage(driver);
    }

    /**
     * Select persona from dropdown.
     */
    public DashboardPage selectPersona(String persona) {
        try {
            selectByVisibleText(DROPDOWN_PERSONA, persona);
        } catch (Exception e) {
            click(DROPDOWN_PERSONA);
            By personaOption = By.xpath("//*[contains(text(),'" + persona + "')]");
            click(personaOption);
        }
        waitForPageLoad();
        logger.info("Selected persona: {}", persona);
        capturePageScreenshot("Persona_Selected_" + persona);
        return this;
    }
}
