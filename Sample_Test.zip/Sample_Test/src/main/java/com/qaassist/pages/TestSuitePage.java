package com.qaassist.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Page object for Test Suite management — create, view, execute suites.
 */
public class TestSuitePage extends BasePage {

    // ── Locators ──
    private static final By BTN_NEW_TEST_SUITE = By.xpath(
            "//*[contains(text(),'New Test Suite') or @data-testid='btn-new-suite']");
    private static final By INPUT_SUITE_NAME = By.cssSelector(
            "input[data-testid='suite-name'], input[name='suiteName'], .suite-name-input");
    private static final By INPUT_SUITE_DESCRIPTION = By.cssSelector(
            "textarea[data-testid='suite-description'], textarea[name='description'], .suite-desc-input");
    private static final By BTN_CREATE_SUITE = By.xpath(
            "//*[contains(text(),'Create') or contains(text(),'Submit') or @data-testid='btn-create-suite']");
    private static final By LIST_TEST_SUITES = By.cssSelector(
            ".test-suite-item, .suite-row, [data-testid='suite-item']");
    private static final By LIST_TEST_CASES = By.cssSelector(
            ".test-case-item, .testcase-row, [data-testid='test-case-row']");
    private static final By CHECKBOX_SELECT_ALL = By.cssSelector(
            "input[data-testid='select-all'], .select-all-checkbox, [aria-label='Select All']");
    private static final By BTN_GENERATE_TEST_DATA = By.xpath(
            "//*[contains(text(),'Generate Test Data') or @data-testid='btn-generate-data']");
    private static final By BTN_EXECUTE_SUITE = By.xpath(
            "//*[contains(text(),'Execute Test Suite') or contains(text(),'Execute') or @data-testid='btn-execute']");
    private static final By SPINNER_LOADING = By.cssSelector(
            ".spinner, .loading, [data-testid='loading-indicator']");
    private static final By LBL_SUITE_CREATED = By.xpath(
            "//*[contains(text(),'created') or contains(text(),'successfully')]");

    public TestSuitePage(WebDriver driver) {
        super(driver);
    }

    /**
     * Click on New Test Suite button.
     */
    public TestSuitePage clickNewTestSuite() {
        click(BTN_NEW_TEST_SUITE);
        logger.info("Clicked New Test Suite");
        capturePageScreenshot("NewTestSuite_Dialog");
        return this;
    }

    /**
     * Enter suite name.
     */
    public TestSuitePage enterSuiteName(String suiteName) {
        type(INPUT_SUITE_NAME, suiteName);
        logger.info("Entered suite name: {}", suiteName);
        return this;
    }

    /**
     * Enter suite description.
     */
    public TestSuitePage enterSuiteDescription(String description) {
        type(INPUT_SUITE_DESCRIPTION, description);
        logger.info("Entered suite description");
        return this;
    }

    /**
     * Submit suite creation.
     */
    public TestSuitePage submitCreateSuite() {
        click(BTN_CREATE_SUITE);
        waitForPageLoad();
        logger.info("Submitted suite creation");
        capturePageScreenshot("Suite_Created");
        return this;
    }

    /**
     * Create a new test suite with name and description.
     */
    public TestSuitePage createTestSuite(String suiteName, String description) {
        clickNewTestSuite();
        enterSuiteName(suiteName);
        enterSuiteDescription(description);
        submitCreateSuite();
        return this;
    }

    /**
     * Select all test cases in the suite.
     */
    public TestSuitePage selectAllTestCases() {
        click(CHECKBOX_SELECT_ALL);
        logger.info("Selected all test cases");
        capturePageScreenshot("All_TestCases_Selected");
        return this;
    }

    /**
     * Click Generate Test Data button.
     */
    public TestSuitePage clickGenerateTestData() {
        click(BTN_GENERATE_TEST_DATA);
        logger.info("Clicked Generate Test Data");
        return this;
    }

    /**
     * Wait for test data generation to complete.
     */
    public TestSuitePage waitForTestDataGeneration() {
        // Wait for loading spinner to disappear
        waitForElementToDisappear(SPINNER_LOADING, 120);
        waitForPageLoad();
        logger.info("Test data generation completed");
        capturePageScreenshot("TestData_Generated");
        return this;
    }

    /**
     * Check if Execute Test Suite button is enabled/available.
     */
    public boolean isExecuteSuiteEnabled() {
        boolean enabled = isElementEnabled(BTN_EXECUTE_SUITE);
        logger.info("Execute Suite enabled: {}", enabled);
        return enabled;
    }

    /**
     * Verify suite appears in list.
     */
    public boolean isSuiteVisible(String suiteName) {
        By suiteLocator = By.xpath(
                "//*[contains(@class,'suite') or contains(@class,'list')]" +
                        "//*[contains(text(),'" + suiteName + "')]");
        return isElementDisplayed(suiteLocator, 10);
    }

    /**
     * Get count of test cases listed.
     */
    public int getTestCaseCount() {
        List<WebElement> cases = driver.findElements(LIST_TEST_CASES);
        return cases.size();
    }

    /**
     * Get all suite names.
     */
    public List<String> getAllSuiteNames() {
        List<WebElement> elements = driver.findElements(LIST_TEST_SUITES);
        return elements.stream().map(WebElement::getText).toList();
    }
}
