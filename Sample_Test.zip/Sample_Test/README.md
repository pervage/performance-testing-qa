# QA Assist — UI and API Integrated Test Framework

## Overview
An integrated automation framework combining **UI (Selenium WebDriver)** and **API (RestAssured)** testing using **Page Object Model** with **TestNG**.

## Architecture

```
src/
├── main/java/com/qaassist/
│   ├── api/              # RestAssured API clients (BaseAPI, ProjectInsightsAPI, etc.)
│   ├── base/             # BaseTest, DriverManager (ThreadLocal for parallel)
│   ├── config/           # ConfigReader — property-based configuration
│   ├── constants/        # Constants — no hard-coded values in tests
│   ├── exceptions/       # FrameworkException — custom exception handling
│   ├── listeners/        # TestNG Listeners, RetryAnalyzer, qTest integration
│   ├── mock/             # WireMock stubs for API mocking
│   ├── pages/            # Page Object Model classes
│   └── utils/            # Excel, Screenshot, Wait, Report, Logger utilities
├── main/resources/
│   ├── config.properties # Framework configuration
│   └── log4j2.xml        # Logging configuration
└── test/
    ├── java/com/qaassist/tests/
    │   ├── TC01_UploadExcelVerifyTest.java
    │   ├── TC02_EndToEndWorkflowTest.java
    │   ├── TC03_EditAddTestCaseTest.java
    │   ├── TC_FETCH_NEG_03_NegativeFetchTest.java
    │   ├── TC05_DeleteFolderTest.java
    │   └── mock/APIWireMockTests.java
    └── resources/testdata/
        ├── QA_Assist_TestData.xlsx
        └── QA_Assist_Upload.xlsx
```

## Key Features

| Feature | Implementation |
|---|---|
| **UI Testing** | Selenium WebDriver + Page Object Model |
| **API Testing** | RestAssured with BaseAPI pattern |
| **Test Framework** | TestNG (Listeners, Annotations, Priorities, Groups) |
| **Reporting** | Extent Reports (HTML with screenshots) |
| **Logging** | Log4j2 (Console + File + Error file) |
| **Data Driven** | Apache POI — Excel-based test data |
| **Mocking** | WireMock — positive/negative/edge-case API stubs |
| **Screenshots** | On every success page + mandatory on failure |
| **Parallel Execution** | ThreadLocal WebDriver + TestNG parallel config |
| **Headless Mode** | Configurable via property/profile/CLI |
| **Retry** | RetryAnalyzer for flaky tests |
| **qTest Integration** | Auto-push results to qTest |
| **CI/CD** | GitHub Actions (PR, daily smoke, alternate regression) |
| **Exception Handling** | Custom FrameworkException throughout |

## Test Cases

| ID | Description | Type |
|---|---|---|
| TC_01 | Upload Excel and verify test case details vs first row | Smoke, Regression |
| TC_02 | E2E: Auth → Dashboard → Project → Suite → AI → Execute → Defect | Regression, E2E |
| TC_03 | Edit test case and add/remove via API | Regression |
| TC_FETCH_NEG_03 | Negative: Fetch non-available tests from chatbot | Regression, Negative |
| TC_05 | Delete folder from Excel upload and verify removal | Regression |
| API Mocks | WireMock-based positive/negative/edge-case API tests | Mock, API |

## Running Tests

### Prerequisites
- Java 17+
- Maven 3.8+
- Chrome browser (for UI tests)

### Commands

```bash
# Run all tests
mvn clean test

# Run smoke tests
mvn clean test -Psmoke

# Run regression tests
mvn clean test -Pregression

# Run in headless mode
mvn clean test -Pheadless

# Run parallel
mvn clean test -Pparallel

# Run specific test
mvn clean test -Dtest=TC01_UploadExcelVerifyTest

# Run with specific browser
mvn clean test -Dbrowser=firefox -Dheadless=true

# Run API mock tests only
mvn clean test -Dtest=com.qaassist.tests.mock.APIWireMockTests
```

## Configuration

Edit `src/main/resources/config.properties`:

```properties
app.base.url=https://qa-assist-uat.example.com
browser=chrome
headless=false
api.base.url=https://qa-assist-uat.example.com/api/v1
excel.testdata.path=src/test/resources/testdata/QA_Assist_TestData.xlsx
```

## qTest Integration

1. Create a free trial qTest account
2. Set properties in `config.properties`:
   ```properties
   qtest.enabled=true
   qtest.base.url=https://your-domain.qtestnet.com
   qtest.api.token=YOUR_API_TOKEN
   qtest.project.id=YOUR_PROJECT_ID
   ```
3. Results auto-push to qTest on each test execution

## CI/CD — GitHub Actions

| Workflow | Trigger | Suite |
|---|---|---|
| `pr-check.yml` | PR opened/modified | Build + API Mocks |
| `smoke-daily.yml` | Daily at 6am UTC | Smoke tests |
| `regression-alternate.yml` | Mon/Wed/Fri at 2am UTC | Full regression |

## Excel Test Data Format

| Module/Folder | Test Case Name | Pre-Conditions | Priority | Test Case Type |
|---|---|---|---|---|
| NopCommerce | Login Test | Valid credentials | High | Functional |

## Project Management

Use Git for version control:
```bash
git init
git add .
git commit -m "Initial framework setup"
git remote add origin <your-repo-url>
git push -u origin main
```
